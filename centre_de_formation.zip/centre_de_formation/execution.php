<?php
include_once('connexion.php');

$id=$_GET['id'];

$nom=$_POST['nom'];
$postnom=$_POST['postnom'];
$prenom=$_POST['prenom'];
$civil = $_POST['civil'];
$genre = $_POST['Homme'];
$date_nais = $_POST['naissance'];
$lieu_nais = $_POST['lieu'];
$mail = $_POST['mail'];
$telephone = $_POST['tel'];
$adresse = $_POST['addresse'];
$ville = $_POST['city'];
$pays = $_POST['country'];
$filiere = $_POST['filière'];
#traitement des fichiers multimedia
$att_reussite = $_FILES['reussite'] ['tmp_name'];
$att_reussite= file_get_contents($att_reussite);
$att_reussite= addslashes($att_reussite);
$att_bonne = $_FILES['bonne'] ['tmp_name'];
$att_bonne=file_get_contents($att_bonne);
$att_bonne=addslashes($att_bonne);
$recommande = $_FILES['recommandation'] ['tmp_name'];
$recommande=file_get_contents($recommande);
$recommande=addslashes($recommande);
$photo = $_FILES['photo'] ['tmp_name'];
$photo =file_get_contents($photo);
$photo= addslashes($photo);
$parent_mail = $_POST['par_mail'];
$tel_parent = $_POST['tel_par'];




$req="update inscription set nom='$nom',postnom='$postnom',prenom='$prenom',Etat_civil='$civil' , genre='$genre' , date_naissance='$date_nais',lieu_de_naissance='$lieu_nais' ,mail='$mail' ,telephone='$telephone',adresse='$adresse', ville='$ville',pays='$pays',filiere='$filiere', attestation_de_reussite='$att_reussite' , attestation_de_bonne_vie='$att_bonne',lettre_de_recommandation='$recommande' , photo='$photo' ,email_parent='$parent_mail',telephone_parent='$tel_parent' where id='$id'";
$req=$conn->query($req);
header('location:admin.html');



?>
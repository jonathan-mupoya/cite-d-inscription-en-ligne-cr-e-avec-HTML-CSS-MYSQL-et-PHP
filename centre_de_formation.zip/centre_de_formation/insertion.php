<?php

include_once("connexion.php");
try{

    
    
    if(isset($_POST["submit"])){
        if($_POST["submit"]=="Soumettre ma candidature"){
            if(isset($_POST["nom"],$_POST["postnom"],$_POST["prenom"],$_POST['civil'],$_POST['Homme'],
            $_POST['naissance'],$_POST['lieu'],$_POST['mail'],$_POST['tel'],$_POST['addresse'],
            $_POST['city'],$_POST['country'],$_POST['filière'],$_FILES['reussite'],
            $_FILES['bonne'] ,$_FILES['recommandation'],$_FILES['photo'], $_POST['par_mail'],$_POST['tel_par'])){
                
                
                $matricule=date('YHis');
                $nom = $_POST['nom'];
                $postnom = $_POST['postnom'];
                $prenom = $_POST['prenom'];
                $civil = $_POST['civil'];
                $genre = $_POST['Homme'];
                $date_nais = $_POST['naissance'];
                $lieu_nais = $_POST['lieu'];
                $mail = $_POST['mail'];
                $telephone = $_POST['tel'];
                $adresse = $_POST['addresse'];
                $ville = $_POST['city'];
                $pays = $_POST['country'];
                $filiere = $_POST['filière'];
                #traitement des fichiers multimedia
                $att_reussite = $_FILES['reussite'] ['tmp_name'];
                $att_reussite= file_get_contents($att_reussite);
                $att_reussite= addslashes($att_reussite);
                $att_bonne = $_FILES['bonne'] ['tmp_name'];
                $att_bonne=file_get_contents($att_bonne);
                $att_bonne=addslashes($att_bonne);
                $recommande = $_FILES['recommandation'] ['tmp_name'];
                $recommande=file_get_contents($recommande);
                $recommande=addslashes($recommande);
                $photo = $_FILES['photo'];
                $photo =file_get_contents($photo);
                $parent_mail = $_POST['par_mail'];
                $tel_parent = $_POST['tel_par'];

                $requi="select * from inscription where nom='$nom' and postnom='$postnom' and prenom='$prenom'";
                $requi=$conn->query($requi);
                $recupe=$requi->fetch();

                if($recupe>0)
                {
                    header('location:error_formulaire.html');
                }

                else{
                    if(isset($_POST["nom"],$_POST["postnom"],$_POST["prenom"],$_POST['civil'],$_POST['Homme'],
                    $_POST['naissance'],$_POST['lieu'],$_POST['mail'],$_POST['tel'],$_POST['addresse'],
                    $_POST['city'],$_POST['country'],$_POST['filière'],$_FILES['reussite'],
                    $_FILES['bonne'] ,$_FILES['recommandation'],$_FILES['photo'], $_POST['par_mail'],$_POST['tel_par'])){
                        
                        
                        $matricule=date('YHis');
                        $nom = $_POST['nom'];
                        $postnom = $_POST['postnom'];
                        $prenom = $_POST['prenom'];
                        $civil = $_POST['civil'];
                        $genre = $_POST['Homme'];
                        $date_nais = $_POST['naissance'];
                        $lieu_nais = $_POST['lieu'];
                        $mail = $_POST['mail'];
                        $telephone = $_POST['tel'];
                        $adresse = $_POST['addresse'];
                        $ville = $_POST['city'];
                        $pays = $_POST['country'];
                        $filiere = $_POST['filière'];
                        #traitement des fichiers multimedia
                        $att_reussite = $_FILES['reussite'] ['tmp_name'];
                        $att_reussite= file_get_contents($att_reussite);
                        $att_reussite= addslashes($att_reussite);
                        $att_bonne = $_FILES['bonne'] ['tmp_name'];
                        $att_bonne=file_get_contents($att_bonne);
                        $att_bonne=addslashes($att_bonne);
                        $recommande = $_FILES['recommandation'] ['tmp_name'];
                        $recommande=file_get_contents($recommande);
                        $recommande=addslashes($recommande);
                        $photo = $_FILES['photo'] ["tmp_name"];
                        $photo =file_get_contents($photo);
                        $parent_mail = $_POST['par_mail'];
                        $tel_parent = $_POST['tel_par'];

                        $req=$conn->prepare("insert into inscription(nom , postnom  ,prenom ,Etat_civil , genre , date_naissance  ,lieu_de_naissance ,mail ,telephone ,adresse , ville ,pays ,filiere, attestation_de_reussite , attestation_de_bonne_vie ,lettre_de_recommandation , photo ,email_parent ,telephone_parent,matricule )
                        values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
                        $req->bindParam(1,$nom);
                        $req->bindParam(2,$postnom);
                        $req->bindParam(3,$prenom);
                        $req->bindParam(4,$civil);
                        $req->bindParam(5,$genre);
                        $req->bindParam(6,$date_nais);
                        $req->bindParam(7,$lieu_nais);
                        $req->bindParam(8,$mail);
                        $req->bindParam(9,$telephone);
                        $req->bindParam(10,$adresse);
                        $req->bindParam(11,$ville);
                        $req->bindParam(12,$pays);
                        $req->bindParam(13,$filiere);
                        $req->bindParam(14,$att_reussite);
                        $req->bindParam(15,$att_bonne);
                        $req->bindParam(16,$recommande);
                        $req->bindParam(17,$photo,PDO::PARAM_LOB);
                        $req->bindParam(18,$parent_mail);
                        $req->bindParam(19,$tel_parent);
                        $req->bindParam(20,$matricule);
                        $req->execute();
                    };
                        ?>
                        <!DOCTYPE html>
                        <html lang="fr">
                        <head>
                            <meta charset="UTF-8">
                            <meta name="viewport" content="width=device-width, initial-scale=1.0">
                            <title>université révérend kim</title>
                            <link rel="stylesheet" href="bootstrap.min.css">
                            <link rel="stylesheet" href="index.css">
                            <style>
                                body {
                                    font-family: 'Times New Roman', Times, serif;
                                    background-color: #f5f5f5;
                                    margin: 0;
                                    padding: 0;
                                    color: #333;
                                }
                                .container {
                                    max-width: 800px;
                                    margin: 50px auto;
                                    padding: 20px;
                                    background-color: #fff;
                                    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                                    border-radius: 10px;
                                }
                                .header {
                                    text-align: center;
                                    padding-bottom: 20px;
                                    border-bottom: 2px solid #004080;
                                }
                                .header h1 {
                                    color: #004080;
                                    font-size: 2.5em;
                                }
                                .content {
                                    padding: 20px;
                                }
                                .content p {
                                    font-size: 1.2em;
                                    line-height: 1.6;
                                    margin: 10px 0;
                                }
                                .highlight {
                                    font-weight: bold;
                                    color: #004080;
                                }
                                .footer {
                                    margin-top: 30px;
                                    text-align: center;
                                    font-size: 0.9em;
                                    color: #666;
                                }
                            </style>
                        </head>
                        <?php
    
                        
                            $matricule=date('YHis');
                            $nom = $_POST['nom'];
                            $postnom = $_POST['postnom'];
                            $prenom = $_POST['prenom'];
                            $anne=date('Y');
                            $passe=($anne-1);
                            
    
    
                        ?>
                        <body style="padding-top:100px">
                        <header class="fixed-top bg-white shadow-lg" style="height: 150px;">
                            <div class="row py-2">
                                <div class="col-3 mx-3">
                                    <img src="casquette-de-graduation.png" alt="logo" style="width: 100px;">

                                </div>
                                <div class="col-6 py-4">
                                    <h2 class="fw-bold" style="position: relative; right: 230px;">CENTRE DE FORMATION MMJEA</h2>

                                </div>
                                <div class="col py-4">
                                    <ul class="nav" style="position: relative;right: 300px;">
                                        <li class="nav-link bt text-dark fw-bold"><a class="text-dark fw-bold" href="index.html" >ACCUEIL</a></li>
                                        <li class="nav-link bt text-dark fw-bold"> <a class="text-dark fw-bold" href="apropos.html">A PROPOS</a></li>
                                        <li class="nav-link bt text-dark fw-bold" style="position: relative;left: 220px; bottom: 40px;"><a class="text-dark fw-bold"  href="cours.html">COURS</a></li>
                                        <li class="nav-link bt text-dark fw-bold" style="position: relative;left: 230px; bottom: 40px;"><a class="text-dark fw-bold" href="inscription.html">INSCRIPTION</a></li>
                                        <li class="nav-link bt text-dark fw-bold" style="position: relative;left: 440px; bottom: 80px;"> <a class="text-dark fw-bold" href="conctact.html">CONTACT</a></li>
                                    </ul>

                                </div>

                            </div>

                        </header>
                            <div class="container">
                                <div class="header">
                                    <h1>CENTRE DE FORMATION MMJEA</h1>
                                </div>
                                <div class="content">
                                    <p>Cher <span><b><?php $nom = $_POST['nom']; echo strtoupper($nom." ".$postnom." ".$prenom);?></span></b>,</p>
                                    <p>
                                        C'est avec un immense plaisir que nous vous confirmons votre inscription au centre de formation MMJEA pour la rentrée <?php echo $passe."-".$anne ?>. Votre candidature, imprégnée de ferveur et d'une incommensurable soif de connaissance, a retenu toute notre attention.
                                    </p>
                                    <p>
                                        Vous rejoindrez ainsi les rangs prestigieux de notre établissement, où vous aurez l'opportunité d'approfondir vos connaissances dans les domaines qui vous passionnent. Nos facultés de medicine, de sciences informatiques, d'économie, de droit  accueilleront vos talents avec enthousiasme. Nos enseignants de renom, dotés d'une expertise incomparable, sauront guider vos pas sur le chemin de l'illumination intellectuelle.
                                    </p>
                                    <p>
                                        Nous sommes convaincus que votre présence au sein de notre communauté universitaire enrichira notre établissement de par votre engagement, votre rigueur académique et votre sens aigu de la réflexion. Soyez assuré de notre soutien indéfectible tout au long de votre parcours.
                                    </p>
                                    <p>
                                        Bienvenue au centre de formation MMJEA, cher <span class="highlight"><?php echo $nom." ".$postnom." ".$prenom; ?></span>. Que cette expérience soit le début d'une brillante carrière au service de vos aspirations.
                                    </p>
                                    <p>voici votre numero matricule <span class="highlight"><?php echo" ". $matricule;?></span></p>
                                    <p>Cordialement,<br>L'équipe administrative de MMJEA</p>
                                </div>
                              
                            </div>

                            <script src="bootstrap.min.js"></script>
                        </body>
                        </html>
                        <?php

                    }
                
                
                
                

    
        }   }
    }
    else{
        header('location=formulaire.html');
    }       
        
}


catch(PDOException $e)
{
    print"Erreur :".$e->getMessage();
}



?>
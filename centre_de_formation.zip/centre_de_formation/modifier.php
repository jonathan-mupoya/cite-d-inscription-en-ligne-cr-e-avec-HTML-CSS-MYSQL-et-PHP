<?php

include_once('connexion.php');

$id=$_GET['id'];

$req="select * from inscription where id='$id'";
$req=$conn->query($req);
$result=$req->fetch(PDO::FETCH_ASSOC);




?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="bootstrap.min.css">
    <link rel="stylesheet" href="modifier.css">
    
</head>
<body>
<div class="container img-fluid py-5">
        <form class="W-50 form-control shadow-lg bg-white border-white" action="execution.php?id=<?php echo $result['id'];?>" method="post" enctype="multipart/form-data">
            <h2 class="text-center text-dark py-3">Formulaire de modification</h2>
            <div class="row ">
                <div class="col">
                    <label class="form-label-input pt-2 fw-bold" for="">Nom</label>
                    <input class="form-control pt-2" type="text" name="nom" value="<?php echo $result['nom'];?>">
                    <label class="form-label-input pt-2 fw-bold" for="">Postnom</label>
                    <input class="form-control pt-2 " type="text" name="postnom" value="<?php echo $result['postnom'];?>">
                    <label class="form-label-input pt-2 fw-bold" for="">Prenom</label>
                    <input class="form-control pt-2" type="text" name="prenom" value="<?php echo $result['prenom'];?>">
                    <label class="form-label-input pt-2 fw-bold" for="">Etat-civil</label>
                    <input class="form-control pt-2" type="text" name="civil" value="<?php echo $result['Etat_civil'];?>">
                    <label class="form-label-input pt-2 fw-bold" for="">Genre</label>
                    <input class="form-control pt-2" type="text" name="Homme" value="<?php echo $result['genre'];?>">
                    <label class="form-label-input pt-2 fw-bold" for="">Date de naissance</label>
                    <input class="form-control pt-2" type="text" name="naissance" value="<?php echo $result['date_naissance'];?>">
                    <label class="form-label-input pt-2 fw-bold" for="">lieu de naissance</label>
                    <input class="form-control pt-2" type="text" name="lieu" value="<?php echo $result['lieu_de_naissance'];?>">
                    <label class="form-label-input pt-2 fw-bold" for="">Mail</label>
                    <input class="form-control pt-2" type="text" name="mail" value="<?php echo $result['mail'];?>">
                    <label class="form-label-input pt-2 fw-bold " for="">Téléphone</label>
                    <input class="form-control pt-2" type="text" name="tel" value="<?php echo $result['telephone'];?>">
                    <label class="form-label-input pt-2 fw-bold " for="">Adresse</label>
                    <input class="form-control pt-2" type="text" name="addresse" value="<?php echo $result['adresse'];?>">
                    <label class="form-label-input pt-2 fw-bold " for="">Ville</label>
                    <input class="form-control pt-2" type="text" name="city" value="<?php echo $result['ville'];?>">
                    <label class="form-label-input pt-2 fw-bold " for="">pays</label>
                    <input class="form-control pt-2" type="text" name="country" value="<?php echo $result['pays'];?>">
                    <label class="form-label-input pt-2 fw-bold " for="">Filière</label>
                    <input class="form-control pt-2" type="text" name="filière" value="<?php echo $result['filiere'];?>">
                    <label class="form-label-input pt-2 fw-bold" for="">Attestation de reussite</label>
                    <input class="form-control pt-2" type="file" name="reussite" accept='.PDF,.docx' value="">
                    <label class="form-label-input pt-2 fw-bold" for="">Attestation de bonne vie et moeurs</label>
                    <input class="form-control pt-2" type="file" name="bonne" accept='.PDF,.docx' value="<?php echo htmlspecialchars($result['attestation_de_bonne_vie']);?>">
                    <label class="form-label-input pt-2 fw-bold " for="">Lettre de recommandation</label>
                    <input class="form-control pt-2" type="file" name="recommandation" accept='.PDF,.docx' value="<?php echo htmlspecialchars($result['lettre_de_recommandation']);?>">
                    <label class="form-label-input pt-2 fw-bold " for="">Photo</label>
                    <input class="form-control pt-2" type="file" name="photo" accept='.png,.jpg' value="<?php echo htmlspecialchars($result['photo']);?>">
                    <label class="form-label-input pt-2 fw-bold " for="">Mail parent</label>
                    <input class="form-control pt-2" type="text" name="par_mail" value="<?php echo $result['email_parent'];?>">
                    <label class="form-label-input pt-2 fw-bold " for="">Numéro parent</label>
                    <input class="form-control pt-2" type="text" name="tel_par" value="<?php echo $result['telephone_parent'];?>">
                    
                    <input class="form-control pt-2 bg-primary mt-3 fw-bold text-white border-white" type="submit" value="MODIFIER">

                </div>

        </form>
       

    </div>
    
</body>
</html>
<?php
include_once('connexion.php');


$nom=$_POST['nom'];
$motpass=$_POST['motpass'];


if(isset($_POST['nom'],$_POST['motpass'])){
    $req="select * from administrateur where nom='$nom' and mot_de_passe='$motpass'  ";
    $req=$conn->query($req);
    $result=$req->fetch(PDO::FETCH_ASSOC);
}

if ($result>0 )
{
    header("location:back.html?nom=$result[nom] & prenom=$result[prenom]");
    exit();
}
else{
    header('location:error_admin.html');
  

}




?>
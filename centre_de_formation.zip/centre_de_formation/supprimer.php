<?php
include_once('connexion.php');

$id=$_GET['id'];
$nom =$_GET['nom'];
$prenom=$_GET['prenom'];


echo $prenom;


$rec="select photo from administrateur where nom='$nom' and prenom='$prenom'";
$rec=$conn->query($rec);
$recu=$rec->fetch(PDO::FETCH_ASSOC);


$req="delete from inscription where id='$id'";
$req=$conn->query($req);
header("location:admin.html")


?>
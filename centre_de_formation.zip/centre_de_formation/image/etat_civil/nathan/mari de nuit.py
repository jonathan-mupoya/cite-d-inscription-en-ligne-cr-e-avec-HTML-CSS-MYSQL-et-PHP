from tkinter import*
from customtkinter import*
from PIL import Image,ImageTk
import sqlite3


root=CTk()
root.geometry("1000x1000")
root.title("ATTESTATION DE MARIAGE")
root.config(bg="#91adad")


mara=CTkFrame(root,bg_color="white",fg_color="white",width=800,height=1000)
mara.place(x=200,y=0)
act=CTkFrame(mara,bg_color="black",fg_color="black",width=160,height=5)
act.place(x=270,y=300)
def actemariage(nomma,datemag,lieunma,datenma,profma,residencema,nationma,nomperma,profperma,residenceperma,nommerma,profmerma,residencemerma,nomfm,lieufm,datenfm,proffm,residfm,nationfm,nompermie,profpermie,residpermie,nommermie,profmermie,residmermi,datepj,dotem,dateverdot,temoind,residtmoi,nomb,prov,vill,distcte,comm5,bureet,bursec,nomac,volum):

    mcomn = f"province : {prov} | ville : {vill}\nDistrict : {distcte} | commune : {comm5}\nBureau prem : {bureet} | bureau sec : {bursec}\n N° : {nomac} | volume : {volum}"
    nom_bourg = nomb

    date_pj = datepj
    dote = dotem
    datevrdot = dateverdot
    temoindt = temoind
    residence_t = residtmoi

    nom_f = nomfm
    daten_f = f"{lieufm} le {datenfm}"
    prof_f = proffm
    residence_f = residfm
    nationalite_f = nationfm

    nomp_f = nompermie
    profp_f = profpermie
    residencep_f = residpermie
    nomm_f = nommermie
    profm_f = profmermie
    residencem_f = residmermi


    nomp_ma = nomperma
    profp_a = profperma
    residencep_m = residenceperma
    nomm_ma = nommerma
    profm_ma = profmerma 
    residencem_ma = residencemerma

    nom_ma = nomma
    daten_dma = f"{lieunma} le {datenma}"
    prof_m = profma
    residence_ma = residencema
    nationalite_ma = nationma

    datemg = datemag


    

    con=sqlite3.connect("gerer.db")
    cur=con.cursor()
    req = "CREATE TABLE IF NOT EXISTS mari (id INTEGER PRIMARY KEY AUTOINCREMENT,nom_ma TEXT, daten_dma TEXT, prof_m TEXT, residence_ma TEXT, nationalite_ma TEXT, datemg TEXT,nomp_ma TEXT, profp_a TEXT, residencep_m TEXT, nomm_ma TEXT, profm_ma TEXT, residencem_ma TEXT,nom_f TEXT,daten_f TEXT,prof_f TEXT,residence_f TEXT,nationalite_f TEXT,nomp_f TEXT, profp_f TEXT, residencep_f TEXT, nomm_f TEXT, profm_f TEXT, residencem_f TEXT,     date_pj TEXT, dote INTEGER, datevrdot TEXT, temoindt TEXT, residence_t TEXT, nom_bourg TEXT, mcomn TEXT)"
    cur.execute(req)
    con.commit()
    print("bon")
    con.close()



def update_cj():
    pol = commune5.get()
    typedoc.configure(text=pol)
    typedoc.after(100,update_cj)

image2 = Image.open("rdc1.png")
image2 = image2.resize((150,100))
image2 = ImageTk.PhotoImage(image2)
drapeau = Label(mara,image=image2,text=" ")
drapeau.place(x=600,y=20)
lbl=CTkLabel(mara,bg_color="white",text="REPUBLIQUE DEMOCRATIQUE DU CONGO",font=("Arial",17,"bold"))
lbl.place(x=5,y=5)
lbl=CTkLabel(mara,bg_color="white",text="Province de",font=("Arial",16,"bold"))
lbl.place(x=5,y=40)

province5=CTkEntry(mara,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text=".......................................",width=200)
province5.place(x=100,y=40)

lbl=CTkLabel(mara,bg_color="white",text="Ville de",font=("Arial",16,"bold"))
lbl.place(x=5,y=70)

ville=CTkEntry(mara,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text="..........................................",width=200)
ville.place(x=100,y=70)

lbl=CTkLabel(mara,bg_color="white",text="District de",font=("Arial",16,"bold"))
lbl.place(x=5,y=100)

district=CTkEntry(mara,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text="......................................",width=200)
district.place(x=100,y=100)

lbl=CTkLabel(mara,bg_color="white",text="Territoire/commune de",font=("Arial",16,"bold"))
lbl.place(x=5,y=130)
commune5=CTkEntry(mara,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text=".......................................",width=200)
commune5.place(x=180,y=130)
lbl=CTkLabel(mara,bg_color="white",text="Bureau principal de l'etat civil de",font=("Arial",16,"bold"))
lbl.place(x=5,y=160)
buretat=CTkEntry(mara,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text=".......................................",width=200)
buretat.place(x=270,y=160)

lbl=CTkLabel(mara,bg_color="white",text="Bureau secondaire de l'etat civil de",font=("Arial",16,"bold"))
lbl.place(x=5,y=190)
bursec=CTkEntry(mara,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text=".......................................",width=200)
bursec.place(x=280,y=190)

lbl=CTkLabel(mara,bg_color="white",text="Acte n°",font=("Arial",16,"bold"))
lbl.place(x=5,y=220)
numacte=CTkEntry(mara,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text=".......................................",width=200)
numacte.place(x=80,y=220)

lbl=CTkLabel(mara,bg_color="white",text="Volume",font=("Arial",16,"bold"))
lbl.place(x=250,y=220)
volume=CTkEntry(mara,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text=".......................................",width=200)
volume.place(x=330,y=220)
lbl=CTkLabel(mara,bg_color="white",text="ACTE DE MARIAGE",font=("Arial",16,"bold"))
lbl.place(x=275,y=270)
lbl=CTkLabel(mara,bg_color="white",text="A la date du ",font=("Arial",16))
lbl.place(x=10,y=330)
datemarg=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text=".....................................",width=200)
datemarg.place(x=100,y=330)

lbl=CTkLabel(mara,bg_color="white",text="devant l'officiel de l'état civil de",font=("Arial",16))
lbl.place(x=230,y=330)
bourg=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text=".......................................................................",width=300)
bourg.place(x=460,y=330)
lbl=CTkLabel(mara,bg_color="white",text="A comparu en seance publique ",font=("Arial",16))
lbl.place(x=10,y= 350)

lbl=CTkLabel(mara,bg_color="white",text="le nommé ",font=("Arial",16))
lbl.place(x=240,y=350)
nommari=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="..........................................................",width=200)
nommari.place(x=325,y=350)

lbl=CTkLabel(mara,bg_color="white",text="né(e)à ",font=("Arial",16))
lbl.place(x=10,y=370)
naissmari=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="....................................................................................",width=300)
naissmari.place(x=80,y=370)

lbl=CTkLabel(mara,bg_color="white",text="le",font=("Arial",16))
lbl.place(x=280,y=370)
lieumari=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text=".........................................................",width=100)
lieumari.place(x=295,y=370)

lbl=CTkLabel(mara,bg_color="white",text="profession",font=("Arial",16))
lbl.place(x=400,y=370)
profmari=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="........................................................................",width=200)
profmari.place(x=480,y=370)

lbl=CTkLabel(mara,bg_color="white",text="résidant à ",font=("Arial",16))
lbl.place(x=10,y=390)
residmari=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................................................................................................",width=300)
residmari.place(x=100,y=390)

lbl=CTkLabel(mara,bg_color="white",text=" de nationalité ",font=("Arial",16))
lbl.place(x=400,y=390)
natmari=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="........................................",width=150)
natmari.place(x=500,y=390)

lbl=CTkLabel(mara,bg_color="white",text="fils de ",font=("Arial",16))
lbl.place(x=10,y=410)
parentmari=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="..........................................................",width=200)
parentmari.place(x=60,y=410)


lbl=CTkLabel(mara,bg_color="white",text=" Profession ",font=("Arial",16))
lbl.place(x=250,y=410)
profperemari=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="..........................................................................",width=150)
profperemari.place(x=330,y=410)


lbl=CTkLabel(mara,bg_color="white",text=" Residant à",font=("Arial",16))
lbl.place(x=470,y=410)
adperemari=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................",width=200)
adperemari.place(x=570,y=410)

lbl=CTkLabel(mara,bg_color="white",text="Et de",font=("Arial",16))
lbl.place(x=10,y=430)
meremari=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text=".......................................................................",width=200)
meremari.place(x=60,y=430)
lbl=CTkLabel(mara,bg_color="white",text=" Profession ",font=("Arial",16))
lbl.place(x=250,y=430)
profmeremari=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................",width=200)
profmeremari.place(x=330,y=430)
lbl=CTkLabel(mara,bg_color="white",text=" Residant à",font=("Arial",16))
lbl.place(x=470,y=430)
admeremari=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................",width=200)
admeremari.place(x=570,y=430)

lbl=CTkLabel(mara,bg_color="white",text="Et lanommé(e) ",font=("Arial",16))
lbl.place(x=10,y=450)
nommariee=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="...........................................................................",width=300)
nommariee.place(x=120,y=450)

lbl=CTkLabel(mara,bg_color="white",text="né(e) à ",font=("Arial",16))
lbl.place(x=420,y=450)
naissmariee=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="...............................................................................",width=300)
naissmariee.place(x=470,y=450)

lbl=CTkLabel(mara,bg_color="white",text="le",font=("Arial",16))
lbl.place(x=10,y=470)
lieumariee=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text=".........................................................",width=200)
lieumariee.place(x=30,y=470)

lbl=CTkLabel(mara,bg_color="white",text="profession  ",font=("Arial",16))
lbl.place(x=250,y=470)
profmariee=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="......................................................................",width=300)
profmariee.place(x=350,y=470)

lbl=CTkLabel(mara,bg_color="white",text=" Résidant à",font=("Arial",16))
lbl.place(x=600,y=470)
residmariee=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="..............................................................................................................................................",width=400)
residmariee.place(x=10,y=490)

lbl=CTkLabel(mara,bg_color="white",text=" de nationalité ",font=("Arial",16))
lbl.place(x=400,y=490)
natmariee=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="............................................",width=200)
natmariee.place(x=500,y=490)

#88888888888888888888888888888
lbl=CTkLabel(mara,bg_color="white",text="Fille de ",font=("Arial",16))
lbl.place(x=10,y=510)
peremariee=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................",width=150)
peremariee.place(x=80,y=510)

lbl=CTkLabel(mara,bg_color="white",text=" Profession ",font=("Arial",16))
lbl.place(x=250,y=510)
profperemariee=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................",width=150)
profperemariee.place(x=350,y=510)


lbl=CTkLabel(mara,bg_color="white",text=" Residant à",font=("Arial",16))
lbl.place(x=470,y=510)
adperemariee=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................",width=200)
adperemariee.place(x=570,y=510)

lbl=CTkLabel(mara,bg_color="white",text=" Et de",font=("Arial",16))
lbl.place(x=10,y=530)
meremariee=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................",width=200)
meremariee.place(x=80,y=530)
lbl=CTkLabel(mara,bg_color="white",text=" Profession ",font=("Arial",16))
lbl.place(x=250,y=530)
profmeremariee=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................",width=150)
profmeremariee.place(x=350,y=530)
lbl=CTkLabel(mara,bg_color="white",text=" Residant à",font=("Arial",16))
lbl.place(x=470,y=530)
admeremariee=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................",width=200)
admeremariee.place(x=570,y=530)





lbl=CTkLabel(mara,bg_color="white",text="Les quels nous ont requis procéder à la celebration du mariage projeté entre eux \n et dont nous avons publié le projet comformement aux prescrit de l'article 384 de la loi du\n 15 juilllet 2016 completant celle du 1er Aout 1987 par voie de (proclamation)(affichage)\nfaite en date du ",font=("Arial",16),justify="left")
lbl.place(x=10,y=580)
dateenre=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................",width=200)
dateenre.place(x=130,y=630)

lbl=CTkLabel(mara,bg_color="white",text="à",font=("Arial",16))
lbl.place(x=350,y=630)

typedoc=CTkLabel(mara,bg_color="white",font=("Arial",16))
typedoc.place(x=400,y=630)
update_cj()


lbl=CTkLabel(mara,bg_color="white",text=" et nous ont produit à ct effet les documents ci-après: Epoux et Epouse Une attestation \nde résidence et de célibat",font=("Arial",16),justify="left")
lbl.place(x=20,y=670)


lbl=CTkLabel(mara,bg_color="white",text="faisant suite à la requisition ,lecture des pieces relatives à leur état civil étant fait, nous leur avons instruit de\nleurs droits et devoirs respectifs et leur avons demandé s'ils veulent se prendre en mariage pour mari et\nfemme chacun d'eux ayant repondu séparement affirmative ,prononçons qu'ils sont unis légalement \npar le mariage dont le dote de",font=("Arial",16),justify="left")
lbl.place(x=20,y=720)
dot=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text=".....................",width=100)
dot.place(x=250,y=770)
lbl=CTkLabel(mara,bg_color="white",text="versée en date du ",font=("Arial",16))
lbl.place(x=350,y=770)
datversedot=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................",width=200)
datversedot.place(x=480,y=770)
lbl=CTkLabel(mara,bg_color="white",text="en presence de ",font=("Arial",16))
lbl.place(x=10,y=790)
temoin=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="..........................................",width=200)
temoin.place(x=150,y=790)
lbl=CTkLabel(mara,bg_color="white",text="residant à ",font=("Arial",16))
lbl.place(x=350,y=790)
residetemoin=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................................................",width=350)
residetemoin.place(x=450,y=800)
lbl=CTkLabel(mara,bg_color="white",text="les epoux ont adopté le regime matrimonial de la communauté universelle des bien\n la lecture de l'acte à été faite en presence des témoins qui contresignent avec nous \n en foi de quoi nous avons dressé le present acte",font=("Arial",16))
lbl.place(x=50,y=840)
valider=CTkButton(mara,text="ENREGISTRER",font=("Arial",14),corner_radius=50,bg_color="white",fg_color="blue",command=lambda:actemariage(nommari.get(),datemarg.get(),naissmari.get(),lieumari.get(),profmari.get(),residmari.get(),natmari.get(),parentmari.get(),profperemari.get(),admeremari.get(),meremari.get(),profmeremari.get(),admeremari.get(),nommariee.get(),naissmariee.get(),lieumariee.get(),profmariee.get(),residmariee.get(),natmariee.get(),peremariee.get(),profperemariee.get(),adperemariee.get(),meremariee.get(),profmeremariee.get(),admeremariee.get(),dateenre.get(),dot.get(),datversedot.get(),temoin.get(),residetemoin.get(),bourg.get(),province5.get(),ville.get(),district.get(),commune5.get(),buretat.get(),bursec.get(),numacte.get(),volume.get()))
valider.place(x=360,y=400)



root.mainloop()

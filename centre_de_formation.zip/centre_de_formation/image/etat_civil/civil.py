from tkinter import *
from PIL import Image,ImageTk
from customtkinter import *
from tkinter import ttk,messagebox
import sqlite3
from fpdf import FPDF
from tkcalendar import DateEntry


root = CTk()
root.geometry("1280x720+0+0")
root.config(bg="#91adad")
coleurAcc = "#107a7a"
arbcolor = "#9e5959"

#===================Acceuil==============================================================
unCadre=CTkFrame(root,fg_color="#107a7a",bg_color="#91adad",corner_radius=20,width=1000,height=600)
unCadre.place(x=150,y=50)
texte = CTkLabel(unCadre,text="REPUBLIQUE DEMOCRATIQUE DU CONGO\nVILLE PROVINCE DE KINSHASA",font=("Arial",20),text_color="#ffffff",fg_color="#107a7a")
texte.place(x=300,y=80)

image1 = Image.open("kinlogo.png")
image1 = image1.resize((150,100))
image1 = ImageTk.PhotoImage(image1)
logoKin = Label(unCadre,image=image1,text=" ")
logoKin.place(x=1100,y=100)

img7 = Image.open("rato.png")
img7 = img7.resize((150,100))
img7 = ImageTk.PhotoImage(img7)
logoKiny = Label(unCadre,image=img7,text=" ")
logoKiny.place(x=100,y=40)



#=========fin Acceuil===============================================================================

#--------------------base de donnees--------------------------------
def ouvrirbase():
    unCadre.place_forget()
    baseCadre.place(x=150,y=50)
    actualiser()



def retourA():
    baseCadre.place_forget()
    actualiser()
    unCadre.place(x=150,y=50)
    

def ouvrit_table(event):
    fot = combobase.get()
    if fot == 'Actes de mariage':
        naisFrame.place_forget()
        decFrame.place_forget()
        mariFrame.place(x=0,y=100)
    elif fot == 'Actes de decés':
        naisFrame.place_forget()
        mariFrame.place_forget()
        decFrame.place(x=0,y=100)
    else:
        mariFrame.place_forget()
        decFrame.place_forget()
        naisFrame.place(x=0,y=100)




baseCadre = CTkFrame(root,fg_color="#107a7a",bg_color="#91adad",width=1000,height=700,corner_radius= 20) 
labbase = CTkLabel(baseCadre,text="GESTION DE BASE DE DONNNEES",font=("Arial",25,"bold"),text_color="#ffffff")
labbase.place(x=310,y=50)


#oprtu = StringVar(value='Actes de naissance')
combobase = CTkComboBox(baseCadre,values=['Actes de naissance','Actes de mariage','Actes de decés'],border_color="#107a7a",dropdown_fg_color="#107a7a",dropdown_text_color="#ffffff",width=180)
combobase.configure(command=lambda event:ouvrit_table(event))
combobase.place(x=100,y=50)


#suppression
def supactenaissance():
    con=sqlite3.connect("gerer.db")
    cur=con.cursor()
    req="select * from info"
    cur.execute(req)
    con.commit()
    for i in cur:
        cur.execute("DELETE from info where id=?",(i[0],))
    con.commit()

def supactemari():
    con=sqlite3.connect("gerer.db")
    cur=con.cursor()
    req="select * from mari"
    cur.execute(req)
    con.commit()
    for i in cur:
        cur.execute("DELETE from mari where id=?",(i[0],))
    con.commit()

def supactedeces():
    con=sqlite3.connect("gerer.db")
    cur=con.cursor()
    req="select * deces mari"
    cur.execute(req)
    con.commit()
    for i in cur:
        cur.execute("DELETE from deces where id=?",(i[0],))
    con.commit()
    




#=========================naissance================================================================================
def actualiser():
    con=sqlite3.connect("gerer.db")
    cur=con.cursor()
    items = basetabnais.get_children()
    for it in items:
        basetabnais.delete(it)
    req = "SELECT * FROM info"
    selec = cur.execute(req)
    for row in selec:
        basetabnais.insert("",END, values=row)
    con.commit()
    con.close()


    con=sqlite3.connect("gerer.db")
    cur=con.cursor()
    col = basetabmari.get_children()
    for cot in col :
        basetabmari.delete(str(cot))    
    req = "SELECT * FROM mari"
    selct = cur.execute(req)
    for item in selct:
        basetabmari.insert("",END,values=str(item))
    con.commit()
    con.close()

def recherchebasenaiss(valeurnaiss,tabnaiss):
    new=valeurnaiss
    items = tabnaiss
    for it in items:
        basetabnais.delete(it)
    con=sqlite3.connect("gerer.db")
    cur=con.cursor()
    reqn = "SELECT * FROM info WHERE nouvaun = ?"
    selec = cur.execute(reqn,(new,))
    for row in selec:
        basetabnais.insert("",END, values=row)
    con.commit()
    con.close()

def enregistrer ( nomn, nomp, nomm, datedenaissance, avenu, num, comn,mcom,nomb,dateren):
        
    
    if nomn and nomp and nomm and datedenaissance and avenu and num and comn and mcom and nomb and dateren:
        
        messagebox.showinfo('Enregistrement','Enregistrer avec succés')

    
        con=sqlite3.connect("gerer.db")
        cur=con.cursor()
        req=""" CREATE TABLE IF NOT EXISTS info(id INTEGER PRIMARY KEY AUTOINCREMENT,nouvaun VARCHAR(200), daten VARCHAR(200), nompe VARCHAR(200), nomme VARCHAR(200), avenue VARCHAR(200), num INTEGER, commn VARCHAR(200), mcom VARCHAR(200), nombour VARCHAR(200), datef VARCHAR(50))"""
        cur.execute(req)
        con.commit()
        print(" LA TABLE A ETE CREEE AVEC SUCCES")
        con.close()

        con=sqlite3.connect("gerer.db")
        cur=con.cursor()
        req=" INSERT INTO info(nouvaun, daten, nompe, nomme, avenue, num, commn, mcom, nombour, datef) VALUES (?,?,?,?,?,?,?,?,?,?)"
        cur.execute(req, (nomn, datedenaissance, nomp, nomm, avenu, num, comn, mcom, nomb, str(dateren)))
        con.commit()
        print( "ENREGISTRER")
        con.close()

        

        data = f"Je soussigné..{nomb}..Officier de l'Etat Civil de la commune de ..{mcom}..,\natteste par la présente qu'il ressort des documents en ma possession que ..{nomn}..\nFils(fille) de ...{nomp}..et de ..{nomm}.. résidant sur l'avenue\n..{avenu}.. N°.{num}., commune de la ..{comn}.., de nationalité Congolaise, est effectivement né(e) à\nKinshasa, le ..{dateren}.."

        ppdf = FPDF()
        ppdf.add_page()

        ppdf.set_font("Arial",size=14)
        ppdf.multi_cell(0,5,txt=f"Ville de Kinshasa\nCommune de ..{mcom}..\nService de l'Etat-Civil",border=0,align='L')
        ppdf.set_font("Arial",size=20,style="BU")

        ppdf.set_xy(20,50)
        ppdf.cell(0,10,txt="ATTESTATION DE NAISSANCE",align="C",border=0)

        ppdf.set_font("Arial",size=12)
        ppdf.set_xy(10,80)
        ppdf.multi_cell(0,5,txt=data,border=0,align="L")

        ppdf.set_font("Arial",size=12)
        ppdf.set_xy(100,120)
        ppdf.multi_cell(0,10,txt=f"Fait à ..{mcom}.., le ..{dateren}..\nL'officier de l'Etat Civil\n{nomb}",align="C",border=0)

        ppdf.output(f"{nomn}.pdf")
    else:
        messagebox.showwarning('Attention','Veuillez remplir\nTous les champs de saisie')

#-------------------------------------------------------------------------------------------------------
        
def enregistrerdeces(nomdcd,jourdcd,moisdcd,anneedcd,heuredcd,minutedcd,lieudcd,lieunaisdcd,datenaisdcd,profdcd,rediencedcd,nomdcl,jourdcl,moidcl,anneedcl,lieudcl,heuredcl,minutedcl,lieunaisdcl,datenaisdcl,profdcl,residencedcl,nometciv,lieunaisetciv,datenaisetciv,profetciv,residenceetciv,languet,interpetciv,nomofficier,province,ville,district,commune,secteur,bureau1,bureau2,numacte,volume,nompar,lieunaispar,datepar,profpar,residencepar):


    #parent
    nom_p = nompar
    daten_p = f"{lieunaispar} le {datepar}"
    prof_p = profpar
    residence_p = residencepar


    #personne mort
    nom_m = nomdcd
    fait_m =f"le {jourdcd}/{moisdcd}/{anneedcd}"
    heure_m =f"{heuredcd} : {minutedcd}"
    lieu_m = lieudcd
    daten_m = f"{lieunaisdcd} le {datenaisdcd}"
    prof_m = profdcd
    residence_m = rediencedcd

    #declarant
    nom_d = nomdcl
    date_d =f"{jourdcl}/{moidcl}/{anneedcl}"
    heure_d =f"{heuredcl} : {minutedcl}"
    lieu_d = lieudcl
    daten_n =f"{lieunaisdcl} le {datenaisdcl}"
    prof_d = profdcl
    residence_d = residencedcl

    #etat civil du mort
    nom_moud = nometciv
    daten_moud = f"{lieunaisetciv} le {datenaisetciv}"
    prof_moud = profetciv
    residence_moud = residenceetciv
    langue_inter = languet 
    interprete = interpetciv

    #maison comunale
    officier = nomofficier
    info_com = f"Province : {province} | Ville : {ville}\nDistrict : {district} | Commune : {commune}\nSecteur : {secteur} | Bureau_p : {bureau1}\nBureau2 : {bureau2} | N° : {numacte}\nVolume : {volume}"

    con=sqlite3.connect("gerer.db")
    cur=con.cursor()
    req = "CREATE TABLE IF NOT EXISTS deces (id INTEGER PRIMARY KEY AUTOINCREMENT,nom_m TEXT,fait_m TEXT,heure_m TEXT,lieu_m TEXT,daten_m TEXT,prof_m TEXT,residence_m TEXT,nom_d TEXT,date_d TEXT,heure_d TEXT,lieu_d TEXT,daten_n TEXT,prof_d TEXT,residence_d TEXT,nom_moud TEXT,daten_moud TEXT,prof_moud TEXT,residence_moud TEXT,langue_inter TEXT,interprete TEXT,officier TEXT,info_com TEXT,nom_p TEXT,daten_p TEXT,prof_p TEXT,residence_p TEXT)"

    cur.execute(req)
    con.commit()
    con.close
    if nom_m and nom_d and officier and nom_p:
        req = "INSERT INTO deces (nom_m,fait_m,heure_m,lieu_m,daten_m,prof_m,residence_m,nom_d,date_d,heure_d,lieu_d,daten_n,prof_d,residence_d,nom_p,daten_p,prof_p,residence_p,nom_moud,daten_moud,prof_moud,residence_moud,langue_inter,interprete,officier,info_com) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
        cur.execute(req,(nom_m,fait_m,heure_m,lieu_m,daten_m,prof_m,residence_m,nom_d,date_d,heure_d,lieu_d,daten_n,prof_d,residence_d,nom_p,daten_p,prof_p,residence_p,nom_moud,daten_moud,prof_moud,residence_moud,langue_inter,interprete,officier,info_com))
        con.commit()
        print("excellent")
        con.close()
        
        # lie le fichier pdf 
        data = f"L'an deux mille ..{anneedcl}.. le ..{jourdcl}.. jours du mois de ..{moidcl}.. à ..{lieudcl}.. heures ..{heuredcl}.. minutes..{minutedcl}..\nPar devant de nous ..{officier}.. \nOfficier de l'état civil de ..{commune}..\nA comparu ..{nomdcl}..né(e) à ..{lieunaisdcl}.. le ..{datenaisdcl}.. profession ..{profdcl}.. résidant à ..{residencedcl}.."

        data2 = f"le..{jourdcd}.. jour du mois de ..{moisdcd}..  l'an deux mille ..{anneedcd}.. à .... heure ..{heuredcd}.. minutes ..{minutedcd}.. est décédé(e) à ..{lieudcd}.. le(la) nommé(e) ..{nomdcd}.. né(e) à ..{lieunaisdcd}.. le ..{datenaisdcd}.. profession ..{profdcd}.. résidant à ..{rediencedcd}.. fils(fille) de ..{nompar}.. né(e) à ..{lieunaispar}.. le ..{datepar}.. profession ..{profpar}.. résidant à ..{residencepar}\nétat civil : célibataire, marié(e) à, veuf(ve) de, divorcé(e) de ..{nometciv}.. né(e) à ..{lieunaisetciv}.. le ..{datenaisetciv}.. profession ..{profetciv}.. résidant à ..{residenceetciv}.. Lecture de l'acte a été ou connaissance de l'acte ou traduction de l'acte a été faite en ..{languet}..  langue que nous connaissons ou par ..{interpetciv}.. \nL'interprète ayant prêté serment."

        ppdf = FPDF()
        ppdf.add_page()


        ppdf.set_font("Arial",size=15,style="B")
        ppdf.set_xy(10,10)
        ppdf.multi_cell(0,5,txt="République Démocratique du Congo\nProvince de .........................\nVille de .........................\nDistrict de .........................\nTerritoire/Commune de .........................\nChefferie/Secteur .........................\nBureau principale de l'état civil de .........................\nBureau secondaire de l'état civil de .........................\nActe n° ......... volume .........................",align="L")

        ppdf.image('rato.png',x=150,y=10,w=50,h=0,type='png')

        ppdf.set_font("Arial",size=16,style="UB")
        ppdf.set_xy(10,60)
        ppdf.cell(0,10,txt="ACTE DE DECES",align="C",border=0)

        ppdf.set_font("Arial",size=14)
        ppdf.set_xy(20,75)
        ppdf.multi_cell(170,5,txt=data,align="L",border=0)


        ppdf.set_font("Arial",size=14)
        ppdf.set_xy(10,110)
        ppdf.cell(0,10,txt="Lequel(laquelle) nous a declare ce qui suit:",align="C",border=0)


        ppdf.set_font("Arial",size=14)
        ppdf.set_xy(20,120)
        ppdf.multi_cell(0,6,txt=data2,align="L",border=0)

        ppdf.set_font("Arial",size=14)
        ppdf.set_xy(10,200)
        ppdf.cell(0,10,txt="L'interpère ayant prêté serment.",align="L",border=0)
        ppdf.set_font("Arial",size=14)
        ppdf.set_xy(20,220)
        ppdf.cell(0,10,txt="En foi de quoi, nous avans dressé le présent acte",align="L",border=0)


        ppdf.set_font("Arial",size=14)
        ppdf.set_xy(10,235)
        ppdf.cell(0,10,txt="Le(la) déclarant(e)",align="L",border=0)

        ppdf.set_font("Arial",size=14)
        ppdf.set_xy(150,235)
        ppdf.cell(0,10,txt="L'officier de l'état civil",align="L",border=0)


        ppdf.output(f"{nom_m}.pdf")
        messagebox .showinfo('Traitement','taitement avec succés')
    else:
        messagebox.showwarning('Attention','Veuillez remplir le champs obligatoire')



def quitnais ():
    acte.place_forget()
    deces.place_forget()
    mara.place_forget()


def ouvrirnaiss():
    #navzor = val
    for i in range(-1000,0):
        
        acte.place(x=i,y=0)
        deuxCadre.update()
def ouvrirdec():
    for i in range (-500,200):
        deces.place(x=i,y=730)
        deuxCadre.update()
    for j in range(730,0,-2):
        deces.place(x=1,y=j)
        deuxCadre.update()

def ouvrir_mari():
    for i in range (-800,2):
        mara.place(x=i,y=730)
        deuxCadre.update()
    for j in range(1000,0,-2):
        mara.place(x=1,y=j)
        deuxCadre.update()

def Montmari():
    for j in range(1,400):
        mara.place(x=1,y=-j)
        buts.place_forget()
        butp.place(x=700,y=560)
        mara.update()

def quitmari():
    mara.place_forget()
    deces.place_forget()
    acte.place_forget()


def demari():
    for j in range(-400,1):
        mara.place(x=1,y=j)
        butp.place_forget()
        buts.place(x=700,y=560)
        mara.update()



def decmont ():
    for j in range(1,300):
        deces.place(x=1,y=-j)
        deuxCadre.update() 
        suivdec.place_forget()
        precdec.place(x=800,y=555)

def decdec ():
    for j in range(-230,1):
        deces.place(x=1,y=j)
        deces.update()
        precdec.place_forget()
        suivdec.place(x=800,y=555)
        deuxCadre.update()

def update_com ():
    deccomm = commune.get()
    nomcomnal.configure(text=deccomm)
    nomcomnal.after(1000,update_com)

def update_dcl():
    xop = nomdeclar.get()
    parlelangue.configure(text=xop)
    parlelangue.after(1000,update_dcl)

def update_lbl():
    total = boucommun.get()
    nomcom.configure(text=total)
    bouc.configure(text=total)
    bouc.after(1000,update_lbl)


#creation frame
var=StringVar()




naisFrame = CTkFrame(baseCadre,fg_color="#ffffff",width=1000,height=500,corner_radius=0,bg_color="#91adad")
naisFrame.place(x=0,y=100)

retourbutn = CTkButton(naisFrame,text="Accueil",fg_color=coleurAcc,font=("Arial",15),text_color="white",border_width=0,command=retourA,hover_color=arbcolor)
retourbutn.place(x=20,y=40)


actuisnais = CTkButton(naisFrame,text="Actualiser",fg_color=coleurAcc,command=actualiser,border_width=0,font=("Arial",15),hover_color=arbcolor)
actuisnais.place(x=200,y=40)

actuisnais = CTkButton(naisFrame,text="Supprimer",fg_color=coleurAcc,command=supactenaissance,border_width=0,font=("Arial",15),hover_color=arbcolor)
actuisnais.place(x=200,y=460)


labnaiss = Label(naisFrame,text="Actes de naissance",font="Arial 20 bold",fg="#107a7a",bg="#ffffff")
labnaiss.place(x=400,y=100)

# parametre recherche 1
labrechnais = CTkLabel(naisFrame,text="Identité de la personne :",font=("Arial",14),text_color="#65777a")
labrechnais.place(x=450,y=50)
entrechnais =  CTkEntry(naisFrame,font=("Arial",13),width=200,height=30,border_color="#107a7a",corner_radius=10,placeholder_text="Nom,Post-nom et Prenom.....",placeholder_text_color="#bac2c2")
entrechnais.place(x=610,y=50)
butbrechnais = CTkButton(naisFrame,text="Recherche",fg_color="#107a7a",width=150,height=30,bg_color="#107a7a",command=lambda:recherchebasenaiss(entrechnais.get(),basetabnais.get_children()),hover_color=arbcolor)
butbrechnais.place(x=800,y=50)



#fin


basetabnais = ttk.Treeview(naisFrame,columns=(1,2,3,4,5,6,7,8,9,10,11),show="headings")
basetabnais.place(x=150,y=150,width=700,height=300)

basetabnais.heading(1,text="IDn"),
basetabnais.heading(2,text="Nouvau née"),
basetabnais.heading(3,text="Date de naissance"),
basetabnais.heading(4,text="Nom du père"),
basetabnais.heading(5,text="Nom de la mère"),
basetabnais.heading(6,text="Avenue"),
basetabnais.heading(7,text="N°"),
basetabnais.heading(8,text="Commune du née"),
basetabnais.heading(9,text="M Communale"),
basetabnais.heading(10,text="Nom bourgoumestre"),
basetabnais.heading(11,text="Date d'enregistrement")


basetabnais.column(1,width=50),
basetabnais.column(2,width=200),
basetabnais.column(3,width=200),
basetabnais.column(4,width=200),
basetabnais.column(5,width=200),
basetabnais.column(6,width=200),
basetabnais.column(7,width=50),
basetabnais.column(8,width=200),
basetabnais.column(9,width=200),
basetabnais.column(10,width=200),
basetabnais.column(11,width=200)

inscrollnais = CTkScrollbar(basetabnais,orientation="horizontal",command=basetabnais.xview)
inscrollnais.pack(side="bottom",fill="x")

basetabnais.configure(xscrollcommand=inscrollnais.set)

inscrollsnais = CTkScrollbar(basetabnais,orientation="vertical",command=basetabnais.yview)
inscrollsnais.pack(side="right",fill="y")

basetabnais.configure(yscrollcommand=inscrollsnais.set)
#=======================fin==naissance==================================================================
#=========================mariage========================================================================
mariFrame = CTkFrame(baseCadre,fg_color="#ffffff",width=1000,height=500,corner_radius=0,bg_color="#91adad")

actuismari = CTkButton(mariFrame,text="Actualiser",fg_color=coleurAcc,command=actualiser,border_width=0,font=("Arial",15),hover_color=arbcolor)
actuismari.place(x=200,y=40)


labmari = Label(mariFrame,text="Actes de mariage",font="Arial 20 bold",fg="#107a7a",bg="#ffffff")
labmari.place(x=400,y=100)

retourbutm = CTkButton(mariFrame,text="Accueil",fg_color=coleurAcc,font=("Arial",15),text_color="white",border_width=0,command=retourA,hover_color=arbcolor)
retourbutm.place(x=20,y=40)

# parametre recherche 2
labrechmari = CTkLabel(mariFrame,text="Identité de la personne :",font=("Arial",14),text_color="#65777a")
labrechmari.place(x=450,y=50)
entrechmari =  CTkEntry(mariFrame,font=("Arial",13),width=200,height=30,border_color="#107a7a",corner_radius=10,placeholder_text="Nom,Post-nom et Prenom.....",placeholder_text_color="#bac2c2")
entrechmari.place(x=610,y=50)
butbrechmari = CTkButton(mariFrame,text="Recherche",fg_color="#107a7a",width=150,height=30,bg_color="#107a7a",hover_color=arbcolor)
butbrechmari.place(x=800,y=50)
actuisnais = CTkButton(mariFrame,text="Supprimer",fg_color=coleurAcc,command=supactemari,border_width=0,font=("Arial",15),hover_color=arbcolor)
actuisnais.place(x=200,y=460)
#fin


basetabmari = ttk.Treeview(mariFrame,columns=(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31),show="headings")
basetabmari.place(x=150,y=150,width=700,height=300)

basetabmari.heading(1,text="ID"),
basetabmari.heading(2,text="nom mari"),
basetabmari.heading(3,text="daten du mari"),
basetabmari.heading(4,text="profession du mari"),
basetabmari.heading(5,text="residence du mari"),
basetabmari.heading(6,text="nationalité"),
basetabmari.heading(7,text="dete du mariage"),
basetabmari.heading(8,text="père du mari"),
basetabmari.heading(9,text="profession père du mari"),
basetabmari.heading(10,text="résidence père du mari"),
basetabmari.heading(11,text="mère du mari"),
basetabmari.heading(12,text="profession mère du mari"),
basetabmari.heading(13,text="rèsidence mère du mari")
basetabmari.heading(14,text="nom marièe")
basetabmari.heading(15,text="daten du marièe")
basetabmari.heading(16,text="profession du marièe")
basetabmari.heading(17,text="résidence du mariée")
basetabmari.heading(18,text="nationalité du mariée")
basetabmari.heading(19,text="père du mariée")
basetabmari.heading(20,text="profession père du mariée")
basetabmari.heading(21,text="résidence père du mariée")
basetabmari.heading(22,text="mère du mariée")
basetabmari.heading(23,text="profession mère du mariée")
basetabmari.heading(24,text="résidence mère du mariée")
basetabmari.heading(25,text="date projet de mariage")
basetabmari.heading(26,text="dote")
basetabmari.heading(27,text="date versement")
basetabmari.heading(28,text="temoin")
basetabmari.heading(29,text="résidence du temoin")
basetabmari.heading(30,text="bourgoumestre")
basetabmari.heading(31,text="Info communale")



basetabmari.column(1,width=50),
basetabmari.column(2,width=100),
basetabmari.column(3,width=100),
basetabmari.column(4,width=100),
basetabmari.column(5,width=100),
basetabmari.column(6,width=100),
basetabmari.column(7,width=100),
basetabmari.column(8,width=100),
basetabmari.column(9,width=100),
basetabmari.column(10,width=100),
basetabmari.column(11,width=100),
basetabmari.column(12,width=100),
basetabmari.column(13,width=100),
basetabmari.column(14,width=100),
basetabmari.column(15,width=100),
basetabmari.column(16,width=100),
basetabmari.column(17,width=100),
basetabmari.column(18,width=100),
basetabmari.column(19,width=100),
basetabmari.column(20,width=100),
basetabmari.column(21,width=100),
basetabmari.column(22,width=100),
basetabmari.column(23,width=100),
basetabmari.column(24,width=100),
basetabmari.column(25,width=100),
basetabmari.column(26,width=100),
basetabmari.column(27,width=100),
basetabmari.column(28,width=100),
basetabmari.column(29,width=100),
basetabmari.column(30,width=100),
basetabmari.column(31,width=100)



inscrollmari = CTkScrollbar(basetabmari,orientation="horizontal",command=basetabmari.xview)
inscrollmari.pack(side="bottom",fill="x")

basetabmari.configure(xscrollcommand=inscrollmari.set)

inscrollsmari = CTkScrollbar(basetabmari,orientation="vertical",command=basetabmari.yview)
inscrollsmari.pack(side="right",fill="y")

basetabmari.configure(yscrollcommand=inscrollsmari.set)

#=========================fin mariage====================================================================

#======================================deces=====================================================================

decFrame = CTkFrame(baseCadre,fg_color="#ffffff",width=1000,height=500,corner_radius=0,bg_color="#91adad")

labnaiss = Label(decFrame,text="Actes de decés",font="Arial 20 bold",fg="#107a7a",bg="#ffffff")
labnaiss.place(x=400,y=100)

actuisdec = CTkButton(decFrame,text="Actualiser",fg_color=coleurAcc,command=actualiser,border_width=0,font=("Arial",15),hover_color=arbcolor)
actuisdec.place(x=200,y=40)

retourbut = CTkButton(decFrame,text="Accueil",fg_color=coleurAcc,font=("Arial",15),text_color="white",border_width=0,command=retourA,hover_color=arbcolor)
retourbut.place(x=20,y=40)
actuisnais = CTkButton(decFrame,text="Supprimer",fg_color=coleurAcc,command=supactedeces,border_width=0,font=("Arial",15),hover_color=arbcolor)
actuisnais.place(x=200,y=460)


# parametre recherche 3
labrechdec = CTkLabel(decFrame,text="Identité de la personne :",font=("Arial",14),text_color="#65777a")
labrechdec.place(x=450,y=50)
entrechdec =  CTkEntry(decFrame,font=("Arial",13),width=200,height=30,border_color="#107a7a",corner_radius=10,placeholder_text="Nom,Post-nom et Prenom.....",placeholder_text_color="#bac2c2")
entrechdec.place(x=610,y=50)
butbrechdec = CTkButton(decFrame,text="Recherche",fg_color="#107a7a",width=150,height=30,bg_color="#107a7a",hover_color=arbcolor)
butbrechdec.place(x=800,y=50)
#fin


basetabdec = ttk.Treeview(decFrame,columns=(1,2,3,4,5,6,7,8,9,10,11,12,13),show="headings")
basetabdec.place(x=150,y=150,width=700,height=300)

basetabdec.heading(1,text="ID"),
basetabdec.heading(2,text="Matricule"),
basetabdec.heading(3,text="Nom complet"),
basetabdec.heading(4,text="Email @"),
basetabdec.heading(5,text="Genre"),
basetabdec.heading(6,text="Pays"),
basetabdec.heading(7,text="Date de naissance"),
basetabdec.heading(8,text="Contact"),
basetabdec.heading(9,text="Date d'inscription"),
basetabdec.heading(10,text="Filière"),
basetabdec.heading(11,text="Niveau"),
basetabdec.heading(12,text="Année Académique"),
basetabdec.heading(13,text="Adresse")

basetabdec.column(1,width=50),
basetabdec.column(2,width=100),
basetabdec.column(3,width=100),
basetabdec.column(4,width=100),
basetabdec.column(5,width=100),
basetabdec.column(6,width=100),
basetabdec.column(7,width=100),
basetabdec.column(8,width=100),
basetabdec.column(9,width=100),
basetabdec.column(10,width=100),
basetabdec.column(11,width=100),
basetabdec.column(12,width=100),
basetabdec.column(13,width=100)

inscrolldec = CTkScrollbar(basetabdec,orientation="horizontal",command=basetabdec.xview)
inscrolldec.pack(side="bottom",fill="x")

basetabdec.configure(xscrollcommand=inscrolldec.set)

inscrollsdec = CTkScrollbar(basetabdec,orientation="vertical",command=basetabdec.yview)
inscrollsdec.pack(side="right",fill="y")

basetabdec.configure(yscrollcommand=inscrollsdec.set)


#==============================================fin deces==================================================


#------------classic--------------------
navzor = 1
def swicth():
    texteser.place_forget()
    global navzor
    #navzor = val
    if navzor == 1:
        for i in range(-250,70):
            attestd.place(x=i,y=200)
        for j in range(-200,250):
            attestd.place(x=70,y=j)
            deuxCadre.update()

            #unCadre.config(fg_color="#107a7a")
            #deuxCadre.config(bg="#ffffff")
            navzor = 2
    elif navzor == 2:
        for i in range(-250,70):
            attestM.place(x=i,y=200)
        for j in range(-200,200):
            attestM.place(x=70,y=j)
            deuxCadre.update()
            navzor = 3
    #elif navzor is 3 :
    else:
        for i in range(-250,70):
            attestN.place(x=i,y=100)
        for j in range(-200,150):
            attestN.place(x=70,y=j)
            deuxCadre.update()
            navzor = 1
            pok.place_forget()
            pok1.place(x=100,y=330)

navzor2 = 1
def swicth2():
    global navzor2 
    if navzor2 == 1:
        for i in range(70,500):
            attestN.place(x=i,y=150)
            deuxCadre.update()
            navzor2 = 2  
    elif navzor2 == 2 :
        for i in range(70,500):
            attestM.place(x=-i,y=200)
            deuxCadre.update()
            navzor2 = 3
    else :
        for i in range(70,500):
            attestd.place(x=i,y=250)
            navzor2 = 1
            pok1.place_forget()
            pok.place(x=100,y=330)
            texteser.place(x=20,y=100)
            deuxCadre.update()
            



deuxCadre = CTkFrame(unCadre,fg_color="#ffffff",width=1000,height=400,bg_color="#107a7a")
deuxCadre.place(x=0,y=150)


serframe = CTkFrame(deuxCadre,bg_color="#ffffff",width=230,height=230,corner_radius=10,fg_color="#bac9cc")
serframe.place(x=40,y=90)

service = CTkLabel(serframe,text="SERVICE",font=("Arial",20,"bold"),text_color="black")
service.place(x=70,y=20)

texteser = CTkLabel(serframe,text="Nos services sont représenté\nde la manière suivante",font=("Arial",14),text_color="black")
texteser.place(x=20,y=100)



attestN = CTkButton(deuxCadre,text="Attestation de naissance",font=("Arial",14),text_color="#ffffff",width=170,height=50,fg_color=coleurAcc,border_width=0,hover_color="#9e5959",bg_color="#bac9cc",command=ouvrirnaiss)

attestM = CTkButton(deuxCadre,text="Attestation de mariage",font=("Arial",14),text_color="#ffffff",width=170,height=50,fg_color=coleurAcc,border_width=0,hover_color="#9e5959",bg_color="#bac9cc",command=ouvrir_mari)

attestd = CTkButton(deuxCadre,text="Attestation de décès",font=("Arial",14),text_color="#ffffff",width=170,height=50,fg_color=coleurAcc,border_width=0,hover_color="#9e5959",bg_color="#bac9cc",command=ouvrirdec)

pok = CTkButton(deuxCadre,text="Suivant",command=swicth,width=100,fg_color=coleurAcc,hover_color=arbcolor)
pok.place(x=100,y=330)

pok1 = CTkButton(deuxCadre,text="Précédent",command=swicth2,width=100,fg_color=coleurAcc,hover_color=arbcolor)


#-------fin classic-----------------------

#=========================presentationnotre  de l'appli=================================================================
troisCadre = CTkFrame(deuxCadre,fg_color="#b2d3d3",corner_radius=50,width=800,height=400)
troisCadre.place(x=300,y=0)

txtacc = "Découvrez notre nouvelle application pour obtenir facilement et rapidement\nvos attestation de naissance, actes de mariage et actes de décès."

texteutilite = "Remplissez simplement le formuaire, suivez l'avancement de votre demande\net recevez vos documents officiel en un rien de temps."

texteutilite2 = "Simplifiez vos démarches administratives avec notre application pratique et sécurisée.\nVous permet de fournir toutes les informations nécessaires et de recevoir rapidement \ndes documents certifiés."



texte = CTkLabel(troisCadre,text="Présentation de l'application",font=("Arial",20,"bold"))
texte.place(x=200,y=10)

texte = CTkLabel(troisCadre,text=txtacc,font=("Arial",14),text_color="black",fg_color="#b2d3d3")
texte.place(x=120,y=50)

texte = CTkLabel(troisCadre,text="Utilité",font=("Arial",20,"bold"))
texte.place(x=310,y=100)

texte = CTkLabel(troisCadre,text=texteutilite,font=("Arial",14),text_color="black",fg_color="#b2d3d3")
texte.place(x=120,y=135)

texte = CTkLabel(troisCadre,text=texteutilite2,font=("Arial",14),text_color="black",fg_color="#b2d3d3")
texte.place(x=100,y=200)


base = CTkButton(troisCadre,text="Base de données",fg_color=coleurAcc,bg_color="#b2d3d3",corner_radius=50,width=100,height=30,command=ouvrirbase,hover_color=arbcolor)
base.place(x=550,y=350)

base = CTkButton(troisCadre,text="A propos",fg_color=coleurAcc,bg_color="#b2d3d3",width=100,height=30,corner_radius=50,hover_color=arbcolor)
base.place(x=420,y=350)

#================================fin==presentation================================================



#---------------------------------acte de naissance------------------------------------
acte=CTkFrame(unCadre,bg_color="#107a7a",fg_color="white",width=800,height=600,corner_radius=30)




lbl=CTkLabel(acte,bg_color="white",text="Ville de Kinshasa\n\nCommune de \n\nService de l'Etat-Civil",font=("Arial",14,"bold"),justify="left",)
lbl.place(x=10,y=30)



quitternais = CTkButton(acte,text="X",fg_color="#ffffff",text_color="#000000",width=20,command=quitnais,hover_color="red")
quitternais.place(x=760,y=5)

boucommun=CTkEntry(acte,font=("Arial",14,"bold"),placeholder_text="....................",width=200,border_color="white",fg_color="white")
boucommun.place(x=120,y=55)


acta=CTkFrame(acte,bg_color="black",fg_color="black",width=200,height=5)
acta.place(x=300,y=230)

lbl=CTkLabel(acte,bg_color="white",text="ATTESTATION DE NAISSANCE",font=("Arial",14,"bold"))
lbl.place(x=300,y=200)

lbl=CTkLabel(acte,bg_color="white",text="Je soussigné",font=("Arial",14))
lbl.place(x=10,y=300)
nombou=CTkEntry(acte,font=("Arial",14),placeholder_text=".................................................................",width=800,border_color="white",fg_color="white")
nombou.place(x=110,y=300)
lbl=CTkLabel(acte,bg_color="white",text=",Officier de l'Etat Civil de la commune de",font=("Arial",14))
lbl.place(x=400,y=300)
nomcom=CTkLabel(acte,font=("Arial",14),width=100,fg_color="white")
nomcom.place(x=630,y=300)
lbl=CTkLabel(acte,bg_color="white",text="atteste par la présente qu'il ressort des documents en ma possession que",font=("Arial",14))
lbl.place(x=10,y=325)
nomnouveau=CTkEntry(acte,font=("Arial",14),placeholder_text="..................................................",width=800,border_color="white",fg_color="white")
nomnouveau.place(x=470,y=325)
lbl=CTkLabel(acte,bg_color="white",text="Fils(fille) de",font=("Arial",14))
lbl.place(x=10,y=350)
nompere=CTkEntry(acte,font=("Arial",14),placeholder_text="..................................................................",width=600,border_color="white",fg_color="white")
nompere.place(x=100,y=350)
lbl=CTkLabel(acte,bg_color="white",text="et de",font=("Arial",14))
lbl.place(x=390,y=350)
nommere=CTkEntry(acte,font=("Arial",14),placeholder_text=".......................................................",width=200,border_color="white",fg_color="white")
nommere.place(x=420,y=350)
lbl=CTkLabel(acte,bg_color="white",text="Residant sur l'avenue :",font=("Arial",14))
lbl.place(x=10,y=375)
avenu=CTkEntry(acte,font=("Arial",14),placeholder_text="...............................",width=1000,border_color="white",fg_color="white")
avenu.place(x=150,y=375)
lbl=CTkLabel(acte,bg_color="white",text="N°",font=("Arial",14))
lbl.place(x=300,y=375)
numav=CTkEntry(acte,font=("Arial",14),placeholder_text="...........",width=200,border_color="white",fg_color="white")
numav.place(x=320,y=375)
lbl=CTkLabel(acte,bg_color="white",text=", commune de la",font=("Arial",14))
lbl.place(x=370,y=375)
communpers=CTkEntry(acte,font=("Arial",14),placeholder_text=".....................................................",width=400,border_color="white",fg_color="white")
communpers.place(x=480,y=375)

lbl=CTkLabel(acte,bg_color="white",text=", de nationalité Congolaise, est effectivement né(e) à Kinshasa, le",font=("Arial",14))
lbl.place(x=10,y=400)

datedenais=CTkEntry(acte,font=("Arial",14),placeholder_text=".........................................",width=800,border_color="white",fg_color="white")
datedenais.place(x=430,y=400)


lbl=CTkLabel(acte,bg_color="white",text="Fait à",font=("Arial",14))
lbl.place(x=470,y=470)

bouc=CTkLabel(acte,font=("Arial",14),width=100,fg_color="white",justify="left")
bouc.place(x=510,y=470)
update_lbl()

lbl=CTkLabel(acte,bg_color="white",text="le",font=("Arial",14))
lbl.place(x=600,y=470)

datefait = DateEntry(acte,background="green",width=10,font=("Arial",14))
datefait.place(x=920,y=710)

lbl=CTkLabel(acte,bg_color="white",text="L'officier de l'Etat Civil",font=("Arial",15))
lbl.place(x=500,y=520)

gerer = CTkButton(acte,text="ENREGISTRER",width=200,height=40,fg_color="green",font=("Arial",15),command=lambda:enregistrer(nomnouveau.get(),nompere.get(),nommere.get(),datedenais.get(),avenu.get(),numav.get(),communpers.get(),boucommun.get(),nombou.get(),datefait.get_date()),hover_color=arbcolor)
gerer.place(x=200,y=550)



#-----------------------------------------naissance--------------------------------

#------------------------------deces --------------------------------------

deces=CTkFrame(unCadre,fg_color="white",width=900,height=1000)

suivdec = CTkButton(deces,text="suivant",width=100,height=40,fg_color=coleurAcc,font=("Arial",15),hover_color=arbcolor,command=decmont)
suivdec.place(x=800,y=555)
precdec = CTkButton(deces,text="Précédent",width=100,height=40,fg_color=coleurAcc,font=("Arial",15),hover_color=arbcolor,command=decdec)


fermdec = CTkButton(deces,text="X",width=10,height=10,text_color="black",fg_color="white",font=("Arial",15),hover_color="red",command=quitnais)
fermdec.place(x=870,y=0)

image3 = Image.open("rdc1.png")
image3 = image3.resize((150,100))
image3 = ImageTk.PhotoImage(image3)
drapeau = Label(deces,image=image3,text=" ")
drapeau.place(x=700,y=30)




lbl=CTkLabel(deces,bg_color="white",text="REPUBLIQUE DEMOCRATIQUE DU CONGO",font=("Arial",17,"bold"))
lbl.place(x=5,y=5)

lbl=CTkLabel(deces,bg_color="white",text="Province de",font=("Arial",16,"bold"))
lbl.place(x=5,y=40)

province=CTkEntry(deces,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text=".......................................",width=200)
province.place(x=100,y=40)

lbl=CTkLabel(deces,bg_color="white",text="Ville de",font=("Arial",16,"bold"))
lbl.place(x=5,y=70)

ville=CTkEntry(deces,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text="..........................................",width=200)
ville.place(x=100,y=70)

lbl=CTkLabel(deces,bg_color="white",text="District de",font=("Arial",16,"bold"))
lbl.place(x=5,y=100)

district=CTkEntry(deces,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text="......................................",width=200)
district.place(x=100,y=100)

lbl=CTkLabel(deces,bg_color="white",text="Territoire/commune de",font=("Arial",16,"bold"))
lbl.place(x=5,y=130)

commune=CTkEntry(deces,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text=".......................................",width=200)
commune.place(x=180,y=130)

lbl=CTkLabel(deces,bg_color="white",text="Chefferie/Secteur de",font=("Arial",16,"bold"))
lbl.place(x=5,y=160)

secteur=CTkEntry(deces,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text="........................................",width=200)
secteur.place(x=180,y=160)

lbl=CTkLabel(deces,bg_color="white",text="Bureau principale de l'etat civil de",font=("Arial",16,"bold"))
lbl.place(x=5,y=190)

bureau=CTkEntry(deces,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text="........................................",width=200)
bureau.place(x=270,y=190)

lbl=CTkLabel(deces,bg_color="white",text="Bureau secondaire de l'etat civil de",font=("Arial",16,"bold"))
lbl.place(x=5,y=210)

bureau2=CTkEntry(deces,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text=".......................................",width=200)
bureau2.place(x=280,y=210)

lbl=CTkLabel(deces,bg_color="white",text="Acte n°",font=("Arial",16,"bold"))
lbl.place(x=5,y=240)

numacte=CTkEntry(deces,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text=".......................................",width=100)
numacte.place(x=60,y=240)
lbl=CTkLabel(deces,bg_color="white",text="Volume",font=("Arial",16,"bold"))
lbl.place(x=160,y=240)

volume=CTkEntry(deces,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text="........................................",width=100)
volume.place(x=230,y=240)

lbl=CTkLabel(deces,bg_color="white",text="ACTE DE DECES",font=("Arial",16,"bold"))
lbl.place(x=300,y=280)
acta=CTkFrame(deces,bg_color="black",fg_color="black",width=130,height=5)
acta.place(x=300,y=310)

lbl=CTkLabel(deces,bg_color="white",text="L'an deux mille",font=("Arial",16))
lbl.place(x=10,y=330)
annee=CTkEntry(deces,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................",width=150)
annee.place(x=140,y=330)

lbl=CTkLabel(deces,bg_color="white",text="Le",font=("Arial",16))
lbl.place(x=300,y=330)

le=CTkEntry(deces,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text=".....................................",width=150)
le.place(x=330,y=330)

lbl=CTkLabel(deces,bg_color="white",text="jour du mois de",font=("Arial",16))
lbl.place(x=470,y=330)

jour=CTkEntry(deces,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text=".............................",width=150)
jour.place(x=600,y=330)

lbl=CTkLabel(deces,bg_color="white",text="à",font=("Arial",16))
lbl.place(x=10,y=350)

lieu=CTkEntry(deces,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text=".......................................",width=150)
lieu.place(x=40,y=350)

lbl=CTkLabel(deces,bg_color="white",text="heures",font=("Arial",16))
lbl.place(x=180,y=350)

heure=CTkEntry(deces,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text=".......................................",width=150)
heure.place(x=250,y=350)

lbl=CTkLabel(deces,bg_color="white",text="minutes",font=("Arial",16))
lbl.place(x=420,y=350)

minute=CTkEntry(deces,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text=".....................................",width=250)
minute.place(x=500,y=350)


lbl=CTkLabel(deces,bg_color="white",text="Par devant nous",font=("Arial",16))
lbl.place(x=5,y=370)


nomoffi=CTkEntry(deces,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="..............................................................",width=400)
nomoffi.place(x=130,y=370)

lbl=CTkLabel(deces,bg_color="white",text="Officier de l'etat civil de",font=("Arial",16))
lbl.place(x=430,y=370)
nomcomnal=CTkLabel(deces,bg_color="white",font=("Arial",15),fg_color="white",text_color="black",width=150)
nomcomnal.place(x=600,y=370)
update_com()


lbl=CTkLabel(deces,bg_color="white",text="A comparu ",font=("Arial",16))
lbl.place(x=20,y=390)

nomdeclar=CTkEntry(deces,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="............................................................",width=300)
nomdeclar.place(x=110,y=390)

lbl=CTkLabel(deces,bg_color="white",text="né(e) à",font=("Arial",16))
lbl.place(x=370,y=390)
lieunaiss2=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text=".............................................",width=500)
lieunaiss2.place(x=430,y=390)

lbl=CTkLabel(deces,bg_color="white",text="le ",font=("Arial",16))
lbl.place(x=610,y=390)
datenaiss2=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text=".............................",width=500)
datenaiss2.place(x=625,y=390)

lbl=CTkLabel(deces,bg_color="white",text="profession ",font=("Arial",16))
lbl.place(x=10,y=410)
profession2=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="....................................",width=500)
profession2.place(x=90,y=410)

lbl=CTkLabel(deces,bg_color="white",text="résidant à ",font=("Arial",16))
lbl.place(x=250,y=410)
residecle=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="..........................................................................................................................",width=500)
residecle.place(x=320,y=410)

lbl=CTkLabel(deces,bg_color="white",text="lequel(laquelle)nous a déclaré ce qui suit: ",font=("Arial",16,"bold"))
lbl.place(x=150,y=440)

lbl=CTkLabel(deces,bg_color="white",text="le",font=("Arial",16))
lbl.place(x=10,y=470)
jourmort=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text=".....................................",width=500)
jourmort.place(x=30,y=470)

lbl=CTkLabel(deces,bg_color="white",text="jour du mois de ",font=("Arial",16))
lbl.place(x=200,y=470)
jourmois=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text=".....................................",width=500)
jourmois.place(x=312,y=470)

lbl=CTkLabel(deces,bg_color="white",text="l'an deux-mille ",font=("Arial",16))
lbl.place(x=480,y=470)
annmort=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="......................................",width=500)
annmort.place(x=585,y=470)

lbl=CTkLabel(deces,bg_color="white",text="heure ",font=("Arial",16))
lbl.place(x=10,y=490)
heuredcd=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="......................................",width=500)
heuredcd.place(x=50,y=490)

lbl=CTkLabel(deces,bg_color="white",text="minutes ",font=("Arial",16))
lbl.place(x=230,y=490)
minute2=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="...........................",width=500)
minute2.place(x=300,y=490)

lbl=CTkLabel(deces,bg_color="white",text="est décédé(e) à ",font=("Arial",16))
lbl.place(x=450,y=490)
lieudcd=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="............................",width=500)
lieudcd.place(x=560,y=490)

lbl=CTkLabel(deces,bg_color="white",text="le(la)nommé(e) ",font=("Arial",16))
lbl.place(x=10,y=510)
persdcd=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="....................................................",width=500)
persdcd.place(x=120,y=510)


lbl=CTkLabel(deces,bg_color="white",text="né(e) à",font=("Arial",16))
lbl.place(x=340,y=510)
lieunaiss=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text=".........................",width=420)
lieunaiss.place(x=390,y=510)

lbl=CTkLabel(deces,bg_color="white",text="le ",font=("Arial",16))
lbl.place(x=500,y=510)
datenaiss=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text=".......................................",width=400)
datenaiss.place(x=520,y=510)


lbl=CTkLabel(deces,bg_color="white",text="profession ",font=("Arial",16))
lbl.place(x=10,y=530)
profession=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="...........................................",width=500)
profession.place(x=90,y=530)

lbl=CTkLabel(deces,bg_color="white",text="résidant à ",font=("Arial",16))
lbl.place(x=290,y=530)

residence=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="..........................................................................................",width=200)
residence.place(x=380,y=530)

lbl=CTkLabel(deces,bg_color="white",text="fils(fille) de ",font=("Arial",16))
lbl.place(x=10,y=550)
resigemort=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="...................................................",width=500)
resigemort.place(x=90,y=550)

lbl=CTkLabel(deces,bg_color="white",text="né(e) à ",font=("Arial",16))
lbl.place(x=300,y=550)
lieundef=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="...................................................",width=400)
lieundef.place(x=350,y=550)

lbl=CTkLabel(deces,bg_color="white",text="le ",font=("Arial",16))
lbl.place(x=570,y=550)
datendef=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="......................................",width=200)
datendef.place(x=600,y=550)

lbl=CTkLabel(deces,bg_color="white",text="Profession ",font=("Arial",16))
lbl.place(x=10,y=570)
profdef=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="...................................................",width=500)
profdef.place(x=100,y=570)

lbl=CTkLabel(deces,bg_color="white",text="Residant à ",font=("Arial",16))
lbl.place(x=300,y=570)
adressedef=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="..............................................................................................",width=400)
adressedef.place(x=380,y=570)

#---------------------------------------------------------------
lbl=CTkLabel(deces,bg_color="white",text="état civil: celibataire,marié(e) de,veuf(ve) de,divorce de",font=("Arial",16))
lbl.place(x=10,y=620)
etatcdef=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text=".........................................................................................",width=500)
etatcdef.place(x=400,y=620)

lbl=CTkLabel(deces,bg_color="white",text="né (e) à",font=("Arial",16))
lbl.place(x=10,y=640)
datefe=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="................................................................................................",width=500)
datefe.place(x=70,y=640)
lbl=CTkLabel(deces,bg_color="white",text="Le",font=("Arial",16))
lbl.place(x=470,y=640)
lieuf=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="..................................................................",width=500)
lieuf.place(x=490,y=640)

lbl=CTkLabel(deces,bg_color="white",text="profession",font=("Arial",16))
lbl.place(x=10,y=660)
proffe=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="................................................",width=500)
proffe.place(x=100,y=660)

lbl=CTkLabel(deces,bg_color="white",text="Residant à",font=("Arial",16))
lbl.place(x=300,y=660)
adressef=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="..............................................................................................",width=500)
adressef.place(x=380,y=660)

lbl=CTkLabel(deces,bg_color="white",text="Lecture de l'acte a été faite ou taduction da l'acte a été faite en ",font=("Arial",16))
lbl.place(x=10,y=680)
langue=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="..........................................................",width=500)
langue.place(x=465,y=680)
lbl=CTkLabel(deces,bg_color="white",text="langue que nous connaissons ou par",font=("Arial",16))
lbl.place(x=10,y=700)

inter=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="...................................................................",width=500)
inter.place(x=280,y=700)
lbl=CTkLabel(deces,bg_color="white",text="l'interprete ayant preté serment",font=("Arial",16))
lbl.place(x=560,y=700)

lbl=CTkLabel(deces,bg_color="white",text="En foi de quoi nous avons dressé le present acte",font=("Arial",16))
lbl.place(x=10,y=750)
lbl=CTkLabel(deces,bg_color="white",text="Le(la) declarant(te)",font=("Arial",16))
lbl.place(x=10,y=770)

parlelangue=CTkLabel(deces,bg_color="white",font=("Arial",15),fg_color="white",width=100)
parlelangue.place(x=170,y=770)
update_dcl()

lbl=CTkLabel(deces,bg_color="white",text="L'officier de l'état civil",font=("Arial",16))
lbl.place(x=500,y=770)
#-------------------------------fin deces -----------------------------------------




bouvali = CTkButton(deces,text="ENREGISTRER",fg_color=coleurAcc,command=lambda:enregistrerdeces(persdcd.get(),jourmort.get(),jourmois.get(),annmort.get(),heuredcd.get(),minute2.get(),lieudcd.get(),lieunaiss.get(),datenaiss.get(),profession.get(),residence.get(),nomdeclar.get(),le.get(),jour.get(),annee.get(),lieu.get(),heure.get(),minute.get(),lieunaiss2.get(),datenaiss2.get(),profession2.get(),residecle.get(),etatcdef.get(),datefe.get(),lieuf.get(),proffe.get(),adressef.get(),langue.get(),inter.get(),nomoffi.get(),province.get(),ville.get(),district.get(),commune.get(),secteur.get(),bureau.get(),bureau2.get(),numacte.get(),volume.get(),resigemort.get(),lieundef.get(),datendef.get(),profdef.get(),adressedef.get()))
bouvali.place(x=300,y=820)

#######################################################################################################################


mara=CTkFrame(unCadre,bg_color="white",fg_color="white",width=800,height=1000)
act=CTkFrame(mara,bg_color="black",fg_color="black",width=160,height=5)
act.place(x=270,y=300)

buts = CTkButton(mara,text="suivant",width=100,height=40,fg_color=coleurAcc,font=("Arial",15),hover_color=arbcolor,command=Montmari)
buts.place(x=700,y=560)

butp = CTkButton(mara,text="Précédent",width=100,height=40,fg_color=coleurAcc,font=("Arial",15),hover_color=arbcolor,command=demari)

fermdec = CTkButton(mara,text="X",width=10,height=10,text_color="black",fg_color="white",font=("Arial",15),hover_color="red",command=quitmari)
fermdec.place(x=770,y=0)

def actemariage(nomma,datemag,lieunma,datenma,profma,residencema,nationma,nomperma,profperma,residenceperma,nommerma,profmerma,residencemerma,nomfm,lieufm,datenfm,proffm,residfm,nationfm,nompermie,profpermie,residpermie,nommermie,profmermie,residmermi,datepj,dotem,dateverdot,temoind,residtmoi,nomb,prov,vill,distcte,comm5,bureet,bursec,nomac,volum):

    mcomn = f"province : {prov} | ville : {vill}\nDistrict : {distcte} | commune : {comm5}\nBureau prem : {bureet} | bureau sec : {bursec}\n N° : {nomac} | volume : {volum}"
    nom_bourg = nomb

    date_pj = datepj
    dote = dotem
    datevrdot = dateverdot
    temoindt = temoind
    residence_t = residtmoi

    nom_f = nomfm
    daten_f = f"{lieufm} le {datenfm}"
    prof_f = proffm
    residence_f = residfm
    nationalite_f = nationfm

    nomp_f = nompermie
    profp_f = profpermie
    residencep_f = residpermie
    nomm_f = nommermie
    profm_f = profmermie
    residencem_f = residmermi


    nomp_ma = nomperma
    profp_a = profperma
    residencep_m = residenceperma
    nomm_ma = nommerma
    profm_ma = profmerma 
    residencem_ma = residencemerma

    nom_ma = nomma
    daten_dma = f"{lieunma} le {datenma}"
    prof_m = profma
    residence_ma = residencema
    nationalite_ma = nationma

    datemg = datemag

    if mcomn and temoindt and nom_f and nomp_f and nomm_f and nomp_ma and nomm_ma and nom_ma:


        con=sqlite3.connect("gerer.db")
        cur=con.cursor()
        req = "CREATE TABLE IF NOT EXISTS mari (id INTEGER PRIMARY KEY AUTOINCREMENT,nom_ma TEXT, daten_dma TEXT, prof_m TEXT, residence_ma TEXT, nationalite_ma TEXT, datemg TEXT,nomp_ma TEXT, profp_a TEXT, residencep_m TEXT, nomm_ma TEXT, profm_ma TEXT, residencem_ma TEXT,nom_f TEXT,daten_f TEXT,prof_f TEXT,residence_f TEXT,nationalite_f TEXT,nomp_f TEXT, profp_f TEXT, residencep_f TEXT, nomm_f TEXT, profm_f TEXT, residencem_f TEXT, date_pj TEXT, dote INTEGER, datevrdot TEXT, temoindt TEXT, residence_t TEXT, nom_bourg TEXT, mcomn TEXT)"
        cur.execute(req)
        con.commit()
        con.close()


        con=sqlite3.connect("gerer.db")
        cur=con.cursor()
        req = "INSERT INTO mari (nom_ma,daten_dma,prof_m,residence_ma,nationalite_ma,datemg,nomp_ma,profp_a,residencep_m,nomm_ma,profm_ma,residencem_ma,nom_f,daten_f,prof_f,residence_f,nationalite_f,nomp_f,profp_f,residencep_f,nomm_f,profm_f,residencem_f,date_pj,dote,datevrdot,temoindt,residence_t,nom_bourg,mcomn) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"

        cur.execute(req,(nom_ma,daten_dma,prof_m,residence_ma,nationalite_ma,datemg,nomp_ma,profp_a,residencep_m,nomm_ma,profm_ma,residencem_ma,nom_f,daten_f,prof_f,residence_f,nationalite_f,nomp_f,profp_f,residencep_f,nomm_f,profm_f,residencem_f,date_pj,dote,datevrdot,temoindt,residence_t,nom_bourg,mcomn))
        con.commit()
        con.close()

        con=sqlite3.connect("gerer.db")
        cur=con.cursor()
        req = "SELECT * FROM mari"

        selct = cur.execute(req)
        for item in selct:
            basetabmari.insert("",END,values=item)


        messagebox.showinfo("Traitement","Enregistrer avec succés")

        data1 = f"REPUBLIQUE DEMOCRATIQUE DU CONGO\nProvince de ..{prov}..\nVille de ..{vill}..\nDistrict de ..{distcte}..\nTerritoire/Commune de ..{comm5}..\nBureau principal de l'état civil de ..{bureet}..\nBureau secondaire de l'état civil de ..{bursec}..\nActe N° ..{nomac}.. Volume ..{volum}.."

        data2 = f"A la date du ..{datemag}.. devant l'officiel de l'état civil ..{nomb}..\nA comparu en seance publique le nommé ..{nomma}.. né(e) à ..{lieunma}.. le ..{datenma}.. profession ..{profma}.. résidant à ..{residencema}.. de nationalité ..{nationma}..\nFils de ..{nomperma}.. Profession ..{profperma}.. Résidant à ..{residenceperma}.. et de ..{nommerma}.. Profession ..{profmerma}.. Résidant à ..{residencemerma}..\nLa nommée ..{nomfm}.. née à ..{lieufm}.. le ..{datenfm}.. profrssion ..{proffm}.. residant à..{residfm}.. nationalité..{nationfm}..\n fille de..{nompermie}.. profession..{profpermie}.. residant à..{residpermie}..\n et de..{nommermie}.. profession..{profmermie}..residant à..{residmermi}..\n\n les quels nous ont requis à la celebration du mariage projeté entre eux\n et dont nous avons publié le projet conformement aux prescrits de l'article 384 de la loi du 15 juillet 2016 completant celle du 1 aout 1987 par voie de (proclamation)(affichage)\n faite en date du..{datepj}.. à..{comm5}..\n\n et nous ont produit à cet effet les documents ci-après : epoux et epouse une attestation de residence et de celibat\nfaisant suite requisition,lecture des pieces relative à leur etat civil étant fait nous leur avons\n instruit de leurs droits et devoirs respectifs et leur avons demandé \n s'ils veulent se prendre en charge pour mari et femme chacun d'eux ayant repondu separement affirmatif . prononçons que ils sont unis legalement par le mariage dont \n le dote est de ..{dotem}.. versé en date du..{dateverdot}.. en presence de ..{temoind}.. residant à..{residtmoi}..\n\n les epoux ont adopté le regime matrimonial de la communauté universelle des biens \n la lecture de l'acte à été faite en presence des temoins qui contresignent avec nous \n en foi de quoi avons dressé le present acte "

        ppdf = FPDF()
        ppdf.add_page()

        ppdf.set_font("Arial",size=16)
        ppdf.set_xy(10,10)
        ppdf.multi_cell(0,6,txt=data1,align="L",border=0)

        ppdf.set_font("Arial",size=18,style="BU")
        ppdf.set_xy(80,70)
        ppdf.cell(0,6,txt="ACTE DE MARIAGE")

        ppdf.set_font("Arial",size=14)
        ppdf.set_xy(10,100)
        ppdf.multi_cell(0,5,txt=data2,align="L",border=0)

        ppdf.output(f"{nomma}_et_{nomfm}.pdf")


    else:
        messagebox.showinfo("Traitement","Veuillez remplire les champs obligatoire")


def update_cj():
    pol = commune5.get()
    typedoc.configure(text=pol)
    typedoc.after(100,update_cj)

image2 = Image.open("rdc1.png")
image2 = image2.resize((150,100))
image2 = ImageTk.PhotoImage(image2)
drapeau = Label(mara,image=image2,text=" ")
drapeau.place(x=600,y=20)
lbl=CTkLabel(mara,bg_color="white",text="REPUBLIQUE DEMOCRATIQUE DU CONGO",font=("Arial",17,"bold"))
lbl.place(x=5,y=5)
lbl=CTkLabel(mara,bg_color="white",text="Province de",font=("Arial",16,"bold"))
lbl.place(x=5,y=40)



province5=CTkEntry(mara,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text=".......................................",width=200)
province5.place(x=100,y=40)

lbl=CTkLabel(mara,bg_color="white",text="Ville de",font=("Arial",16,"bold"))
lbl.place(x=5,y=70)

ville=CTkEntry(mara,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text="..........................................",width=200)
ville.place(x=100,y=70)

lbl=CTkLabel(mara,bg_color="white",text="District de",font=("Arial",16,"bold"))
lbl.place(x=5,y=100)

district=CTkEntry(mara,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text="......................................",width=200)
district.place(x=100,y=100)

lbl=CTkLabel(mara,bg_color="white",text="Territoire/commune de",font=("Arial",16,"bold"))
lbl.place(x=5,y=130)
commune5=CTkEntry(mara,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text=".......................................",width=200)
commune5.place(x=180,y=130)
lbl=CTkLabel(mara,bg_color="white",text="Bureau principal de l'etat civil de",font=("Arial",16,"bold"))
lbl.place(x=5,y=160)
buretat=CTkEntry(mara,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text=".......................................",width=200)
buretat.place(x=270,y=160)

lbl=CTkLabel(mara,bg_color="white",text="Bureau secondaire de l'etat civil de",font=("Arial",16,"bold"))
lbl.place(x=5,y=190)
bursec=CTkEntry(mara,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text=".......................................",width=200)
bursec.place(x=280,y=190)

lbl=CTkLabel(mara,bg_color="white",text="Acte n°",font=("Arial",16,"bold"))
lbl.place(x=5,y=220)
numacte=CTkEntry(mara,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text=".......................................",width=200)
numacte.place(x=80,y=220)

lbl=CTkLabel(mara,bg_color="white",text="Volume",font=("Arial",16,"bold"))
lbl.place(x=250,y=220)
volume=CTkEntry(mara,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text=".......................................",width=200)
volume.place(x=330,y=220)
lbl=CTkLabel(mara,bg_color="white",text="ACTE DE MARIAGE",font=("Arial",16,"bold"))
lbl.place(x=275,y=270)
lbl=CTkLabel(mara,bg_color="white",text="A la date du ",font=("Arial",16))
lbl.place(x=10,y=330)
datemarg=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text=".....................................",width=200)
datemarg.place(x=100,y=330)

lbl=CTkLabel(mara,bg_color="white",text="devant l'officiel de l'état civil de",font=("Arial",16))
lbl.place(x=230,y=330)
bourg=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text=".......................................................................",width=300)
bourg.place(x=460,y=330)
lbl=CTkLabel(mara,bg_color="white",text="A comparu en seance publique ",font=("Arial",16))
lbl.place(x=10,y= 350)

lbl=CTkLabel(mara,bg_color="white",text="le nommé ",font=("Arial",16))
lbl.place(x=240,y=350)
nommari=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="..........................................................",width=200)
nommari.place(x=325,y=350)

lbl=CTkLabel(mara,bg_color="white",text="né(e)à ",font=("Arial",16))
lbl.place(x=10,y=370)
naissmari=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="....................................................................................",width=300)
naissmari.place(x=80,y=370)

lbl=CTkLabel(mara,bg_color="white",text="le",font=("Arial",16))
lbl.place(x=280,y=370)
lieumari=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text=".........................................................",width=100)
lieumari.place(x=295,y=370)

lbl=CTkLabel(mara,bg_color="white",text="profession",font=("Arial",16))
lbl.place(x=400,y=370)
profmari=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="........................................................................",width=200)
profmari.place(x=480,y=370)

lbl=CTkLabel(mara,bg_color="white",text="résidant à ",font=("Arial",16))
lbl.place(x=10,y=390)
residmari=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................................................................................................",width=300)
residmari.place(x=100,y=390)

lbl=CTkLabel(mara,bg_color="white",text=" de nationalité ",font=("Arial",16))
lbl.place(x=400,y=390)
natmari=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="........................................",width=150)
natmari.place(x=500,y=390)

lbl=CTkLabel(mara,bg_color="white",text="fils de ",font=("Arial",16))
lbl.place(x=10,y=410)
parentmari=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="..........................................................",width=200)
parentmari.place(x=60,y=410)


lbl=CTkLabel(mara,bg_color="white",text=" Profession ",font=("Arial",16))
lbl.place(x=250,y=410)
profperemari=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="..........................................................................",width=150)
profperemari.place(x=330,y=410)


lbl=CTkLabel(mara,bg_color="white",text=" Residant à",font=("Arial",16))
lbl.place(x=470,y=410)
adperemari=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................",width=200)
adperemari.place(x=570,y=410)

lbl=CTkLabel(mara,bg_color="white",text="Et de",font=("Arial",16))
lbl.place(x=10,y=430)
meremari=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text=".......................................................................",width=200)
meremari.place(x=60,y=430)
lbl=CTkLabel(mara,bg_color="white",text=" Profession ",font=("Arial",16))
lbl.place(x=250,y=430)
profmeremari=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................",width=200)
profmeremari.place(x=330,y=430)
lbl=CTkLabel(mara,bg_color="white",text=" Residant à",font=("Arial",16))
lbl.place(x=470,y=430)
admeremari=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................",width=200)
admeremari.place(x=570,y=430)

lbl=CTkLabel(mara,bg_color="white",text="Et lanommé(e) ",font=("Arial",16))
lbl.place(x=10,y=450)
nommariee=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="...........................................................................",width=300)
nommariee.place(x=120,y=450)

lbl=CTkLabel(mara,bg_color="white",text="né(e) à ",font=("Arial",16))
lbl.place(x=420,y=450)
naissmariee=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="...............................................................................",width=300)
naissmariee.place(x=470,y=450)

lbl=CTkLabel(mara,bg_color="white",text="le",font=("Arial",16))
lbl.place(x=10,y=470)
lieumariee=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text=".........................................................",width=200)
lieumariee.place(x=30,y=470)

lbl=CTkLabel(mara,bg_color="white",text="profession  ",font=("Arial",16))
lbl.place(x=250,y=470)
profmariee=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="......................................................................",width=300)
profmariee.place(x=350,y=470)

lbl=CTkLabel(mara,bg_color="white",text=" Résidant à",font=("Arial",16))
lbl.place(x=600,y=470)
residmariee=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="..............................................................................................................................................",width=400)
residmariee.place(x=10,y=490)

lbl=CTkLabel(mara,bg_color="white",text=" de nationalité ",font=("Arial",16))
lbl.place(x=400,y=490)
natmariee=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="............................................",width=200)
natmariee.place(x=500,y=490)


lbl=CTkLabel(mara,bg_color="white",text="Fille de ",font=("Arial",16))
lbl.place(x=10,y=510)
peremariee=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................",width=150)
peremariee.place(x=80,y=510)

lbl=CTkLabel(mara,bg_color="white",text=" Profession ",font=("Arial",16))
lbl.place(x=250,y=510)
profperemariee=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................",width=150)
profperemariee.place(x=350,y=510)


lbl=CTkLabel(mara,bg_color="white",text=" Residant à",font=("Arial",16))
lbl.place(x=470,y=510)
adperemariee=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................",width=200)
adperemariee.place(x=570,y=510)

lbl=CTkLabel(mara,bg_color="white",text=" Et de",font=("Arial",16))
lbl.place(x=10,y=530)
meremariee=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................",width=200)
meremariee.place(x=80,y=530)
lbl=CTkLabel(mara,bg_color="white",text=" Profession ",font=("Arial",16))
lbl.place(x=250,y=530)
profmeremariee=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................",width=150)
profmeremariee.place(x=350,y=530)
lbl=CTkLabel(mara,bg_color="white",text=" Residant à",font=("Arial",16))
lbl.place(x=470,y=530)
admeremariee=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................",width=200)
admeremariee.place(x=570,y=530)





lbl=CTkLabel(mara,bg_color="white",text="Les quels nous ont requis procéder à la celebration du mariage projeté entre eux \n et dont nous avons publié le projet comformement aux prescrit de l'article 384 de la loi du\n 15 juilllet 2016 completant celle du 1er Aout 1987 par voie de (proclamation)(affichage)\nfaite en date du ",font=("Arial",16),justify="left")
lbl.place(x=10,y=580)
dateenre=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................",width=200)
dateenre.place(x=130,y=630)

lbl=CTkLabel(mara,bg_color="white",text="à",font=("Arial",16))
lbl.place(x=350,y=630)

typedoc=CTkLabel(mara,bg_color="white",font=("Arial",16))
typedoc.place(x=400,y=630)
update_cj()


lbl=CTkLabel(mara,bg_color="white",text=" et nous ont produit à ct effet les documents ci-après: Epoux et Epouse Une attestation \nde résidence et de célibat",font=("Arial",16),justify="left")
lbl.place(x=20,y=670)


lbl=CTkLabel(mara,bg_color="white",text="faisant suite à la requisition ,lecture des pieces relatives à leur état civil étant fait, nous leur avons instruit de\nleurs droits et devoirs respectifs et leur avons demandé s'ils veulent se prendre en mariage pour mari et\nfemme chacun d'eux ayant repondu séparement affirmative ,prononçons qu'ils sont unis légalement \npar le mariage dont le dote de",font=("Arial",16),justify="left")
lbl.place(x=20,y=720)
dot=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text=".....................",width=100)
dot.place(x=250,y=770)
lbl=CTkLabel(mara,bg_color="white",text="versée en date du ",font=("Arial",16))
lbl.place(x=350,y=770)
datversedot=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................",width=200)
datversedot.place(x=480,y=770)
lbl=CTkLabel(mara,bg_color="white",text="en presence de ",font=("Arial",16))
lbl.place(x=10,y=790)
temoin=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="..........................................",width=200)
temoin.place(x=150,y=790)
lbl=CTkLabel(mara,bg_color="white",text="residant à ",font=("Arial",16))
lbl.place(x=350,y=790)
residetemoin=CTkEntry(mara,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................................................",width=350)
residetemoin.place(x=450,y=800)
lbl=CTkLabel(mara,bg_color="white",text="les epoux ont adopté le regime matrimonial de la communauté universelle des bien\n la lecture de l'acte à été faite en presence des témoins qui contresignent avec nous \n en foi de quoi nous avons dressé le present acte",font=("Arial",16))
lbl.place(x=50,y=840)
valider=CTkButton(mara,text="ENREGISTRER",font=("Arial",14),corner_radius=50,bg_color="white",hover_color=arbcolor,fg_color=coleurAcc,command=lambda:actemariage(nommari.get(),datemarg.get(),naissmari.get(),lieumari.get(),profmari.get(),residmari.get(),natmari.get(),parentmari.get(),profperemari.get(),admeremari.get(),meremari.get(),profmeremari.get(),admeremari.get(),nommariee.get(),naissmariee.get(),lieumariee.get(),profmariee.get(),residmariee.get(),natmariee.get(),peremariee.get(),profperemariee.get(),adperemariee.get(),meremariee.get(),profmeremariee.get(),admeremariee.get(),dateenre.get(),dot.get(),datversedot.get(),temoin.get(),residetemoin.get(),bourg.get(),province5.get(),ville.get(),district.get(),commune5.get(),buretat.get(),bursec.get(),numacte.get(),volume.get()))
valider.place(x=360,y=920)




root.mainloop()

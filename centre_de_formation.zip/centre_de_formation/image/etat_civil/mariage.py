
import tkinter as tk
import sqlite3
from tkinter import messagebox

#creation de Frame

var=StringVar()

atest=FRAME(bg="black",fg="white",font="Arial 18", width=800, height=600)
atest.place


def enregistrer():
    pays = champ_pays.get()
    province = champ_province.get()
    district = champ_district.get()
    commune = champ_commune.get()
    bureau_principal = champ_bureau_principal.get()
    bureau_secondaire = champ_bureau_secondaire.get()
    numero_acte = champ_numero_acte.get()
    date_mariage = champ_date_mariage.get()
    heure_mariage = champ_heure_mariage.get()
    lieu_mariage = champ_lieu_mariage.get()
    homme_consterne = champ_homme_consterne.get()
    fils_de = champ_fils_de.get()
    profession_homme = champ_profession_homme.get()
    lieu_residence_homme = champ_lieu_residence_homme.get()
    femme_consterne = champ_femme_consterne.get()
    etat_civil_femme = champ_etat_civil_femme.get()
    lieu_residence_femme = champ_lieu_residence_femme.get()
    fille_de = champ_fille_de.get()
    profession_femme = champ_profession_femme.get()
    dote = champ_dote.get()

    conn = sqlite3.connect('actes_mariage.db')
    cursor = conn.cursor()
    
    
    cursor.execute('''CREATE TABLE IF NOT EXISTS actes (
                        pays TEXT,
                        province TEXT,
                        district TEXT,
                        commune TEXT,
                        bureau_principal TEXT,
                        bureau_secondaire TEXT,
                        numero_acte TEXT,
                        date_mariage TEXT,
                        heure_mariage TEXT,
                        lieu_mariage TEXT,
                        homme_consterne TEXT,
                        fils_de TEXT,
                        profession_homme TEXT,
                        lieu_residence_homme TEXT,
                        femme_consterne TEXT,
                        etat_civil_femme TEXT,
                        lieu_residence_femme TEXT,
                        fille_de TEXT,
                        profession_femme TEXT,
                        dote TEXT
                    )''')

 
    cursor.execute('''INSERT INTO actes VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                    (pays, province, district, commune, bureau_principal, bureau_secondaire, numero_acte, date_mariage, heure_mariage,
                     lieu_mariage, homme_consterne, fils_de, profession_homme, lieu_residence_homme, femme_consterne,
                     etat_civil_femme, lieu_residence_femme, fille_de, profession_femme, dote))

    conn.commit()
    conn.close()
    messagebox.showinfo("Enregistrement", "L'acte de mariage a été enregistré avec succès.")


fenetre = tk.Tk()
fenetre.title("Acte de mariage")
fenetre.geometry("800x600")


champ_pays = tk.Entry(fenetre)
champ_pays.pack()

bouton_enregistrer = tk.Button(fenetre, text="Enregistrer", command=enregistrer)
bouton_enregistrer.pack()


fenetre.mainloop()



from tkinter import*
from customtkinter import*
from PIL import Image,ImageTk
import sqlite3
from tkinter import messagebox





root=CTk()
haut = root.winfo_screenheight()
larg = root.winfo_screenwidth()
root.geometry("%dx%d+0+0" % (larg,haut))
root.title("ATTESTATION DE MARIAGE")
root.config(bg="#91adad")

#creation frame
var=StringVar()
def enregistrer(nombourgmestre,nomcommune,nom_né,nom_pere,nom_mere,residence,origine,secteur,territoire,district,province,datenaissance,annéenaissance):
    con=sqlite3.connect("acte.db")
    cur=con.cursor()
    req="""CREATE TABLE IF NOT EXISTS acte(id integer primary key AUTOINCREMENT,nombourgmestre varchar(50),nomcommune varchar(50),nom_né varchar(50),nom_pere varchar(50),nom_mere varchar(50),
residence varchar(50),origine varchar(50),secteur varchar(50),territoire varchar(50),district varchar(50),province varchar(50),datenaissance varchar(50),annéenaissance varchar(50))"""
    cur.execute(req)
    con.commit()
    req="INSERT INTO acte(nombourgmestre,nomcommune,nom_né,nom_pere,nom_mere,residence,origine,secteur,territoire,district,province,datenaissance,annéenaissance) values(?,?,?,?,?,?,?,?,?,?,?,?,?)"
    cur.execute(req,(nombourgmestre,nomcommune,nom_né,nom_pere,nom_mere,residence,origine,secteur,territoire,district,province,datenaissance,annéenaissance))
    con.commit()
    con.close()
    messagebox.showinfo("info","vous avez été enregistré avec succés")
    print("bonjour")

acte=CTkFrame(root,bg_color="white",fg_color="white",width=800,height=700)
acte.place(x=200,y=30)
image2 = Image.open("rdc.png")
image2 = image2.resize((150,100))
image2 = ImageTk.PhotoImage(image2)
drapeau = Label(acte,image=image2,text=" ")
drapeau.place(x=600,y=30)
#insertion de la photo
image1 = Image.open("logo.png")
image1 = image1.resize((90,90))
image1 = ImageTk.PhotoImage(image1)
logoKin = Label(acte,image=image1,text=" ")
logoKin.place(x=50,y=50)



lbl=CTkLabel(acte,bg_color="white",text="REPUBLIQUE DEMOCRATIQUE \n DU CONGO",font=("Arial",14,"bold"))
lbl.place(x=5,y=5)
lbl=CTkLabel(acte,bg_color="white",text="Ville de Kinshasa\n commune de LINGWALA",font=("Arial",14,"bold"))
lbl.place(x=30,y=170)
lbl=CTkLabel(acte,bg_color="white",fg_color="white",text="Service de l'Etat-Civil",font=("Arial",14,"bold"))
lbl.place(x=30,y=200)
act=CTkFrame(acte,bg_color="black",fg_color="black",width=150,height=3)
act.place(x=30,y=220)
acta=CTkFrame(acte,bg_color="black",fg_color="black",width=200,height=5)
acta.place(x=300,y=230)

lbl=CTkLabel(acte,bg_color="white",text="ATTESTATION DE NAISSANCE",font=("Arial",14,"bold"))
lbl.place(x=300,y=200)

lbl=CTkLabel(acte,bg_color="white",text="Je soussigné",font=("Arial",14,"bold"))
lbl.place(x=10,y=300)
nombou=CTkEntry(acte,font=("Arial",14,"bold"),placeholder_text="*****************************************************",width=800,border_color="white",fg_color="white")
nombou.place(x=110,y=300)
lbl=CTkLabel(acte,bg_color="white",text=",Bourgmestre de la commune de",font=("Arial",14,"bold"))
lbl.place(x=390,y=300)
nomcom=CTkEntry(acte,font=("Arial",14,"bold"),placeholder_text="*************************************",width=170,border_color="white",fg_color="white")
nomcom.place(x=630,y=300)
lbl=CTkLabel(acte,bg_color="white",text="Atteste par la presente qu'il ressort des documents en sa possession que",font=("Arial",14,"bold"))
lbl.place(x=10,y=325)
nomnouveau=CTkEntry(acte,font=("Arial",14,"bold"),placeholder_text="**********************************************",width=200,border_color="white",fg_color="white")
nomnouveau.place(x=10,y=350)
lbl=CTkLabel(acte,bg_color="white",text="Fils ou fille de",font=("Arial",14,"bold"))
lbl.place(x=210,y=350)
nompere=CTkEntry(acte,font=("Arial",14,"bold"),placeholder_text="**********************************************",width=200,border_color="white",fg_color="white")
nompere.place(x=310,y=350)
lbl=CTkLabel(acte,bg_color="white",text="ET de",font=("Arial",14,"bold"))
lbl.place(x=520,y=350)
nommere=CTkEntry(acte,font=("Arial",14,"bold"),placeholder_text="**********************************************",width=200,border_color="white",fg_color="white")
nommere.place(x=570,y=350)
lbl=CTkLabel(acte,bg_color="white",text="Residant à :",font=("Arial",14,"bold"))
lbl.place(x=10,y=380)
residence=CTkEntry(acte,font=("Arial",14,"bold"),placeholder_text="***************************************************************************************************************",width=1000,border_color="white",fg_color="white")
residence.place(x=100,y=380)
lbl=CTkLabel(acte,bg_color="white",text="Origine de :",font=("Arial",14,"bold"))
lbl.place(x=10,y=420)
origine=CTkEntry(acte,font=("Arial",14,"bold"),placeholder_text="**********************************************",width=200,border_color="white",fg_color="white")
origine.place(x=100,y=420)
lbl=CTkLabel(acte,bg_color="white",text="Secteur de :",font=("Arial",14,"bold"))
lbl.place(x=310,y=420)
secteur=CTkEntry(acte,font=("Arial",14,"bold"),placeholder_text="**********************************************",width=200,border_color="white",fg_color="white")
secteur.place(x=410,y=420)
lbl=CTkLabel(acte,bg_color="white",text="Territoire de :",font=("Arial",14,"bold"))
lbl.place(x=620,y=420)
territoire=CTkEntry(acte,font=("Arial",14,"bold"),placeholder_text="**********************************************",width=200,border_color="white",fg_color="white")
territoire.place(x=10,y=450)

lbl=CTkLabel(acte,bg_color="white",text="District de :",font=("Arial",14,"bold"))
lbl.place(x=10,y=480)
district=CTkEntry(acte,font=("Arial",14,"bold"),placeholder_text="**********************************************",width=200,border_color="white",fg_color="white")
district.place(x=100,y=480)

lbl=CTkLabel(acte,bg_color="white",text="Province :",font=("Arial",14,"bold"))
lbl.place(x=320,y=480)
province=CTkEntry(acte,font=("Arial",14,"bold"),placeholder_text="**********************************************",width=200,border_color="white",fg_color="white")
province.place(x=430,y=480)

lbl=CTkLabel(acte,bg_color="white",text="Est effectivement né(e) à:",font=("Arial",14,"bold"))
lbl.place(x=10,y=520)
daten=CTkEntry(acte,font=("Arial",14,"bold"),placeholder_text="***********************************************************************************************",width=1000,border_color="white",fg_color="white")
daten.place(x=200,y=520)
lbl=CTkLabel(acte,bg_color="white",text="L'an:",font=("Arial",14,"bold"))
lbl.place(x=10,y=550)
année=CTkEntry(acte,font=("Arial",14,"bold"),placeholder_text="***********************************************************************",width=800,border_color="white",fg_color="white")
année.place(x=90,y=550)

valider=CTkButton(acte,text="ENREGISTRER",font=("Arial",14),corner_radius=50,bg_color="white",fg_color="blue",command=lambda:enregistrer(nombou.get(),nomcom.get(),nomnouveau.get(),nompere.get(),nommere.get(),residence.get(),origine.get(),secteur.get(),territoire.get(),district.get(),province.get(),daten.get(),année.get()))
valider.place(x=100,y=600)
"""
valeur=["monsieur","madame","mademoiselle"]
combo=CTkComboBox(acte,variable=var,values=valeur,fg_color="white")
combo.place(x=550,y=320)"""








root.mainloop()

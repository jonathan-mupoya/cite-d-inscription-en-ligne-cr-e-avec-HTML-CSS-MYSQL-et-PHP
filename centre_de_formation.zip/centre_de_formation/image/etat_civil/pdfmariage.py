from fpdf import FPDF


data1 = f"REPUBLIQUE DEMOCRATIQUE DU CONGO\nProvince de ....\nVille de ....\nDistrict de ....\nTerritoire/Commune de ....\nBureau principal de l'état civil de ....\nBureau secondaire de l'état civil de ....\nActe N° .... Volume ...."

data2 = f"A la date du .... devant l'officiel de l'état civil ....\nA comparu en seance publique le nommé .... né(e) à .... le .... profession .... résidant à .... de nationalité ....\nFils de .... Profession .... Résidant à .... et de .... Profession .... Résidant à ....\nLa nommée .... née à .... le .... profrssion .... residant à.... nationalité....\n fille de.... profession.... residant à....\n et de.... profession....residant à....\n\n les quels nous ont requis à la celebration du mariage projeté entre eux\n et dont nous avons publié le projet conformement aux prescrits de l'article 384 de la loi du 15 juillet 2016 completant celle du 1 aout 1987 par voie de (proclamation)(affichage)\n faite en date du.... à....\n\n et nous ont produit à cet effet les documents ci-après : epoux et epouse une attestation de residence et de celibat\nfaisant suite requisition,lecture des pieces relative à leur etat civil étant fait nous leur avons\n instruit de leurs droits et devoirs respectifs et leur avons demandé \n s'ils veulent se prendre en charge pour mari et femme chacun d'eux ayant repondu separement affirmatif . prononçons que ils sont unis legalement par le mariage dont \n le dote est de .... versé en date du.... en presence de ..... residant à....\n\n les epoux ont adopté le regime matrimonial de la communauté universelle des biens \n la lecture de l'acte à été faite en presence des temoins qui contresignent avec nous \n en foi de quoi avons dressé le present acte "

ppdf = FPDF()
ppdf.add_page()

ppdf.set_font("Arial",size=16)
ppdf.set_xy(10,10)
ppdf.multi_cell(0,6,txt=data1,align="L",border=0)

ppdf.set_font("Arial",size=18,style="BU")
ppdf.set_xy(80,70)
ppdf.cell(0,6,txt="ACTE DE MARIAGE")

ppdf.set_font("Arial",size=14)
ppdf.set_xy(10,100)
ppdf.multi_cell(0,5,txt=data2,align="L",border=0)

ppdf.output("marige.pdf")
from fpdf import FPDF
nomB = 465768
data = f"Je soussigné...{nomB}...Officier de l'Etat Civil de la commune de .......,\natteste par la présente qu'il ressort des documents en ma possession que ......{"charly"}.....\nFils(fille) de .............................et de ............................. résidant sur l'avenue\n.............. N°....., commune de la ..............., de nationalité Congolaise, est effectivement né(e) à\nKinshasa, le ........................."

ppdf = FPDF()
ppdf.add_page()

ppdf.set_font("Arial",size=14)
ppdf.multi_cell(0,5,txt="Ville de Kinshasa\nCommune de .............\nService de l'Etat-Civil",border=0,align='L')
ppdf.set_font("Arial",size=20,style="BU")

ppdf.set_xy(20,50)
ppdf.cell(0,10,txt="ATTESTATION DE NAISSANCE",align="C",border=0)

ppdf.set_font("Arial",size=12)
ppdf.set_xy(10,80)
ppdf.multi_cell(0,5,txt=data,border=0,align="L")

ppdf.set_font("Arial",size=12)
ppdf.set_xy(100,120)
ppdf.multi_cell(0,10,txt="Fait à ..........., le ..../..../......\nL'officier de l'Etat Civil",align="C",border=0)





ppdf.output("exemple.pdf")
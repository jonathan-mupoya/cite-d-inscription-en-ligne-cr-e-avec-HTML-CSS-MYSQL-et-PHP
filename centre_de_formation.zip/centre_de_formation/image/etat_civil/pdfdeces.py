from fpdf import FPDF

data = f"L'an deux mille .................. le .................. jours du mois de ....................... à ....................... heures ................. minutes..............\nPar devant de nous ..................................................... \nA comparu .....................................né(e) à ................................................. le ........................... profession ............................ résidant à .................. le ......................................................................"

data2 = f"le.... jour du mois de ....  l'an deux mille .... à .... heure .... minutes .... est décédé(e) à .... le(la) nommé(e) .... né(e) à .... le .... profession .... résidant à .... fils(fille) de .... né(e) à .... le .... profession .... résidant à .... et de .... né(e) à .... le .... profession .... résidant à ....\nLecture de l'acte été faite ou connaissance de l'acte ou traduction de l'acte à été faite en .... langue que nous connaissons ou par .... "

ppdf = FPDF()
ppdf.add_page()


ppdf.set_font("Arial",size=15,style="B")
ppdf.set_xy(10,10)
ppdf.multi_cell(0,5,txt="République Démocratique du Congo\nProvince de .........................\nVille de .........................\nDistrict de .........................\nTerritoire/Commune de .........................\nChefferie/Secteur .........................\nBureau principale de l'état civil de .........................\nBureau secondaire de l'état civil de .........................\nActe n° ......... volume .........................",align="L")

ppdf.image('rato.png',x=150,y=10,w=50,h=0,type='png')

ppdf.set_font("Arial",size=16,style="UB")
ppdf.set_xy(10,60)
ppdf.cell(0,10,txt="ACTE DE DECES",align="C",border=0)

ppdf.set_font("Arial",size=14)
ppdf.set_xy(20,75)
ppdf.multi_cell(170,5,txt=data,align="L",border=0)


ppdf.set_font("Arial",size=14)
ppdf.set_xy(10,110)
ppdf.cell(0,10,txt="Lequel(laquelle) nous a declare ce qui suit:",align="C",border=0)


ppdf.set_font("Arial",size=14)
ppdf.set_xy(20,120)
ppdf.multi_cell(0,6,txt=data2,align="L",border=0)

ppdf.set_font("Arial",size=14)
ppdf.set_xy(10,200)
ppdf.cell(0,10,txt="L'interpère ayant prêté serment.",align="L",border=0)
ppdf.set_font("Arial",size=14)
ppdf.set_xy(20,220)
ppdf.cell(0,10,txt="En foi de quoi, nous avans dressé le présent acte",align="L",border=0)


ppdf.set_font("Arial",size=14)
ppdf.set_xy(10,235)
ppdf.cell(0,10,txt="Le(la) déclarant(e)",align="L",border=0)

ppdf.set_font("Arial",size=14)
ppdf.set_xy(150,235)
ppdf.cell(0,10,txt="L'officier de l'état civil",align="L",border=0)


ppdf.output("dece.pdf")

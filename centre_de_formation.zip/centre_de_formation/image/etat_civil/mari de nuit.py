from tkinter import*
from customtkinter import*
from PIL import Image,ImageTk
import sqlite3


root=CTk()
"""haut = root.winfo_screenheight()
larg = root.winfo_screenwidth()
root.geometry("%dx%d+0+0" % (larg,haut))"""
root.geometry("1000x1000")
root.title("ATTESTATION DE MARIAGE")
root.config(bg="#91adad")


acte=CTkFrame(root,bg_color="white",fg_color="white",width=800,height=1000)
acte.place(x=200,y=30)
act=CTkFrame(root,bg_color="black",fg_color="black",width=160,height=5)
act.place(x=470,y=330)
def actemariage(province,ville,district,commune,bureau_principal,bureau_secondaire,numero_acte,volume,date_mariage,bourgmestre,nom_mari,date_naissance,profession_mari,residence_mari,nationalite_mari,parent_mari,nom_mariee,naissance_mariee,profession_mariee,residence_mariee,nationalite_mariee,pere_mariee,profession_peremariee,adresse_peremariee,meremariee,profession_meremariee,adresse_meremariee,date_enregistrement,type_document,dote,date_versementdote,temoin,residence_temoin):
    
    con=sqlite3.connect("acte_mariage.db")
    cur=con.cursor()
    req="""CREATE TABLE IF NOT EXISTS acte_mariage(id integer primary key autoincrement ,province varchar(20),ville varchar(20),district varchar(20),commune varchar(20),bureau_principal varchar(20),bureau_secondaire varchar(20),
    numero_acte integer,volume integer,date_mariage varchar(20),bourgmestre varchar(20),nom_mari varchar(20),date_naissance integer,profession_mari varchar(20),residence_mari varchar(50),nationalite_mari varchar(20),parent_mari varchar(20),nom_mariee varchar(20),naissance_mariee integer,
    profession_mariee varchar(20),residence_mariee varchar(50),nationalite_mariee varchar(20),pere_mariee varchar(20),profession_peremariee varchar(20),adresse_peremariee varchar(20),
    mere_mariee varchar(20),profession_mere_mariee varchar(20),adresse_mere_mariee varchar(50),date_enregistrement integer,type_document varchar(20),dote integer,date_versementdote integer,
    temoin varchar(20),residence_temoin varchar(20))"""
    cur.execute(req)
    print("la table a été creée avec succés")
    req="INSERT INTO acte_mariage(province,ville,district,commune,bureau_principal,bureau_secondaire,numero_acte,volume,date_mariage,bourgmestre,nom_mari,date_naissance,profession_mari,residence_mari,nationalite_mari,parent_mari,nom_mariee,naissance_mariee,profession_mariee,residence_mariee,nationalite_mariee,pere_mariee,profession_peremariee,adresse_peremariee,mere_mariee,profession_mere_mariee,adresse_mere_mariee,date_enregistrement,type_document,dote,date_versementdote,temoin,residence_temoin) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
    cur.execute(req,(province,ville,district,commune,bureau_principal,bureau_secondaire,numero_acte,volume,date_mariage,bourgmestre,nom_mari,date_naissance,profession_mari,residence_mari,nationalite_mari,parent_mari,nom_mariee,naissance_mariee,profession_mariee,residence_mariee,nationalite_mariee,pere_mariee,profession_peremariee,adresse_peremariee,meremariee,profession_meremariee,adresse_meremariee,date_enregistrement,type_document,dote,date_versementdote,temoin,residence_temoin))
    con.commit()
    con.close()
    print("marché")


    




image2 = Image.open("rdc.png")
image2 = image2.resize((150,100))
image2 = ImageTk.PhotoImage(image2)
drapeau = Label(acte,image=image2,text=" ")
drapeau.place(x=600,y=20)
lbl=CTkLabel(acte,bg_color="white",text="REPUBLIQUE DEMOCRATIQUE DU CONGO",font=("Arial",17,"bold"))
lbl.place(x=5,y=5)
lbl=CTkLabel(acte,bg_color="white",text="Province de",font=("Arial",16,"bold"))
lbl.place(x=5,y=40)

province=CTkEntry(acte,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text=".......................................",width=200)
province.place(x=100,y=40)

lbl=CTkLabel(acte,bg_color="white",text="Ville de",font=("Arial",16,"bold"))
lbl.place(x=5,y=70)

ville=CTkEntry(acte,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text="..........................................",width=200)
ville.place(x=100,y=70)

lbl=CTkLabel(acte,bg_color="white",text="District de",font=("Arial",16,"bold"))
lbl.place(x=5,y=100)

district=CTkEntry(acte,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text="......................................",width=200)
district.place(x=100,y=100)

lbl=CTkLabel(acte,bg_color="white",text="Territoire/commune de",font=("Arial",16,"bold"))
lbl.place(x=5,y=130)
commune=CTkEntry(acte,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text=".......................................",width=200)
commune.place(x=180,y=130)
lbl=CTkLabel(acte,bg_color="white",text="Bureau principal de l'etat civil de",font=("Arial",16,"bold"))
lbl.place(x=5,y=160)
buretat=CTkEntry(acte,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text=".......................................",width=200)
buretat.place(x=270,y=160)

lbl=CTkLabel(acte,bg_color="white",text="Bureau secondaire de l'etat civil de",font=("Arial",16,"bold"))
lbl.place(x=5,y=190)
bursec=CTkEntry(acte,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text=".......................................",width=200)
bursec.place(x=270,y=190)

lbl=CTkLabel(acte,bg_color="white",text="Acte n°",font=("Arial",16,"bold"))
lbl.place(x=5,y=220)
numacte=CTkEntry(acte,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text=".......................................",width=200)
numacte.place(x=80,y=220)

lbl=CTkLabel(acte,bg_color="white",text="Volume",font=("Arial",16,"bold"))
lbl.place(x=250,y=220)
volume=CTkEntry(acte,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text=".......................................",width=200)
volume.place(x=330,y=220)
lbl=CTkLabel(acte,bg_color="white",text="ACTE DE MARIAGE",font=("Arial",16,"bold"))
lbl.place(x=275,y=270)
lbl=CTkLabel(acte,bg_color="white",text="A la date du ",font=("Arial",16))
lbl.place(x=10,y=330)
datemarg=CTkEntry(acte,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text=".........................",width=150)
datemarg.place(x=100,y=330)

lbl=CTkLabel(acte,bg_color="white",text="devant l'officiel de l'état civil de",font=("Arial",16))
lbl.place(x=230,y=330)
bourg=CTkEntry(acte,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="...............................................",width=150)
bourg.place(x=450,y=330)
lbl=CTkLabel(acte,bg_color="white",text="A comparu en seance publique ",font=("Arial",16))
lbl.place(x=580,y=330)

lbl=CTkLabel(acte,bg_color="white",text="le nommé ",font=("Arial",16))
lbl.place(x=10,y=360)
nommari=CTkEntry(acte,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="..........................................................",width=200)
nommari.place(x=80,y=360)

lbl=CTkLabel(acte,bg_color="white",text=" né(e)à ",font=("Arial",16))
lbl.place(x=270,y=360)
naissmari=CTkEntry(acte,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="........................................",width=150)
naissmari.place(x=330,y=360)

lbl=CTkLabel(acte,bg_color="white",text="profession  ",font=("Arial",16))
lbl.place(x=470,y=360)
profmari=CTkEntry(acte,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text=".......................................................................",width=230)
profmari.place(x=570,y=360)

lbl=CTkLabel(acte,bg_color="white",text=" résidant à ",font=("Arial",16))
lbl.place(x=10,y=390)
residmari=CTkEntry(acte,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................................................................................................",width=300)
residmari.place(x=100,y=390)

lbl=CTkLabel(acte,bg_color="white",text=" de nationalité ",font=("Arial",16))
lbl.place(x=400,y=390)
natmari=CTkEntry(acte,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="........................................",width=150)
natmari.place(x=500,y=390)

lbl=CTkLabel(acte,bg_color="white",text="fils(fille)",font=("Arial",16))
lbl.place(x=10,y=430)
parentmari=CTkEntry(acte,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="........................................",width=150)
parentmari.place(x=80,y=430)

lbl=CTkLabel(acte,bg_color="white",text="  et le(la) nommé(e) ",font=("Arial",16))
lbl.place(x=190,y=430)
nommariee=CTkEntry(acte,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="........................................",width=150)
nommariee.place(x=320,y=430)

lbl=CTkLabel(acte,bg_color="white",text=" né(e)à ",font=("Arial",16))
lbl.place(x=450,y=430)
naissmariee=CTkEntry(acte,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="........................................",width=150)
naissmariee.place(x=500,y=430)

lbl=CTkLabel(acte,bg_color="white",text="profession  ",font=("Arial",16))
lbl.place(x=10,y=470)
profmariee=CTkEntry(acte,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="..................................................",width=150)
profmariee.place(x=90,y=470)


lbl=CTkLabel(acte,bg_color="white",text=" résidant ",font=("Arial",16))
lbl.place(x=200,y=470)
residmariee=CTkEntry(acte,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="...............................................................................",width=250)
residmariee.place(x=270,y=470)

lbl=CTkLabel(acte,bg_color="white",text=" de nationalité ",font=("Arial",16))
lbl.place(x=450,y=470)
natmariee=CTkEntry(acte,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="............................................",width=200)
natmariee.place(x=600,y=470)

lbl=CTkLabel(acte,bg_color="white",text=" Fille de ",font=("Arial",16))
lbl.place(x=10,y=500)
peremariee=CTkEntry(acte,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................",width=150)
peremariee.place(x=80,y=500)

lbl=CTkLabel(acte,bg_color="white",text=" Profession ",font=("Arial",16))
lbl.place(x=250,y=500)
profperemariee=CTkEntry(acte,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................",width=150)
profperemariee.place(x=350,y=500)


lbl=CTkLabel(acte,bg_color="white",text=" Residant à",font=("Arial",16))
lbl.place(x=470,y=500)
adperemariee=CTkEntry(acte,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................",width=200)
adperemariee.place(x=570,y=500)

lbl=CTkLabel(acte,bg_color="white",text=" Et de",font=("Arial",16))
lbl.place(x=10,y=530)
meremariee=CTkEntry(acte,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................",width=200)
meremariee.place(x=80,y=530)
lbl=CTkLabel(acte,bg_color="white",text=" Profession ",font=("Arial",16))
lbl.place(x=250,y=530)
profmeremariee=CTkEntry(acte,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................",width=150)
profmeremariee.place(x=350,y=530)
lbl=CTkLabel(acte,bg_color="white",text=" Residant à",font=("Arial",16))
lbl.place(x=470,y=530)
admeremariee=CTkEntry(acte,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................",width=200)
admeremariee.place(x=570,y=530)





lbl=CTkLabel(acte,bg_color="white",text="Les quels nous ont requis procéder à la celebration du mariage projeté entre eux \n et dont nous avons publié le projet comformement aux prescrit de l'article 384 de la loi du\n 15 juilllet 2016 completant celle du 1er Aout 1987 par voie de (proclamation)(affichage) ",font=("Arial",16))
lbl.place(x=10,y=600)
lbl=CTkLabel(acte,bg_color="white",text=" fait en date du",font=("Arial",16))
lbl.place(x=10,y=670)
dateenre=CTkEntry(acte,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................",width=200)
dateenre.place(x=150,y=670)
lbl=CTkLabel(acte,bg_color="white",text=" et nous ont produit à ct effet les documents ci-après:",font=("Arial",16))
lbl.place(x=350,y=670)
typedoc=CTkEntry(acte,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text=".........................................................................................................................................",width=500)
typedoc.place(x=10,y=670)

lbl=CTkLabel(acte,bg_color="white",text="faisant suite à la requisition ,lecture des pieces relatives à leur état civil étant fait,\n nous leur avons instruit de leurs droits et devoirs respectifs et leur avons demandé  \n s'ils veulent se prendre en mariage pour mari et femme chacun d'eux \n ayant repondu séparement affirmative ,prononçons qu'ils sont unis légalement par le mariage dont le dote de",font=("Arial",16))
lbl.place(x=10,y=700)
dot=CTkEntry(acte,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text=".........................................................................................................................................",width=500)
dot.place(x=10,y=770)
lbl=CTkLabel(acte,bg_color="white",text="versée en date du ",font=("Arial",16))
lbl.place(x=400,y=770)
datversedot=CTkEntry(acte,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................",width=200)
datversedot.place(x=550,y=770)
lbl=CTkLabel(acte,bg_color="white",text="en presence de ",font=("Arial",16))
lbl.place(x=10,y=800)
temoin=CTkEntry(acte,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................",width=200)
temoin.place(x=150,y=800)
lbl=CTkLabel(acte,bg_color="white",text="residant à ",font=("Arial",16))
lbl.place(x=350,y=800)
residetemoin=CTkEntry(acte,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................................................................................",width=350)
residetemoin.place(x=450,y=800)
lbl=CTkLabel(acte,bg_color="white",text="les epoux ont adopté le regime matrimonial de la communauté universelle des bien\n la lecture de l'acte à été faite en presence des témoins qui contresignent avec nous \n en foi de quoi nous avons dressé le present acte",font=("Arial",16))
lbl.place(x=10,y=840)
valider=CTkButton(acte,text="ENREGISTRER",font=("Arial",14),corner_radius=50,bg_color="white",fg_color="blue",command=lambda:actemariage(province.get(),ville.get(),district.get(),commune.get(),buretat.get(),bursec.get(),numacte.get(),volume.get(),datemarg.get(),bourg.get(),nommari.get(),naissmari.get(),profmari.get()
,residmari.get(),natmari.get(),parentmari.get(),nommariee.get(),naissmariee.get(),profmariee.get(),residmariee.get(),natmariee.get(),peremariee.get(),profperemariee.get(),adperemariee.get(),meremariee.get(),profmeremariee.get(),admeremariee.get(),dateenre.get(),typedoc.get(),dot.get(),datversedot.get(),temoin.get(),residetemoin.get()))
valider.place(x=100,y=920)
































root.mainloop()

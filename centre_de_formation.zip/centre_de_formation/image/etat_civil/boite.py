from tkinter import *
from tkinter import filedialog
from customtkinter import *
import PyPDF2

def ouvrirpdf():
    chemin = filedialog.asksaveasfilename(filetypes=[("Fichiers PDF","*.pdf")])

    if chemin:
        with open(chemin, "rb") as fichier:
            lecteurpdf = PyPDF2.PdfReader(fichier)
            contenu =""
            for nombrepage in range(lecteurpdf.numPages):
                page = lecteurpdf.getPage(nombrepage)
                contenu += page.extract_text()

    zone.insert(END,contenu)

root = CTk()
root.geometry("1000x700")

boiteframe = Frame(root,bg="#5d5e4a",width=800,height=600)
boiteframe.place(x=100,y=50)

zone = CTkTextbox(boiteframe,width=500,height=500)
zone.place(x=50,y=50)

boutou = CTkButton(root,text="Ouvrir",command=ouvrirpdf)
boutou.place(x=600,y=540)





root.mainloop()
#### Création du formulaire

import tkinter as tk
from tkinter import messagebox
import sqlite3

# Création de la base de données
conn = sqlite3.connect('actes_deces.db')
c = conn.cursor()
c.execute("""CREATE TABLE IF NOT EXISTS actes (
            nom text,
            post_nom text,
            prenom text,
            cause_deces text,
            date_naissance text,
            lieu_naissance text,
            date_deces text,
            annee_deces text,
            identite_decret text
            )""")
conn.commit()

# Création de la fenêtre
fenetre = tk.Tk()
fenetre.title("ACTE DE DECES")
fenetre.geometry("800x600")
fenetre.configure(bg='light blue')

# Fonction pour enregistrer les données
def enregistrer():
    conn = sqlite3.connect('actes_deces.db')
    c = conn.cursor()
    c.execute("INSERT INTO actes VALUES (:nom, :post_nom, :prenom, :cause_deces, :date_naissance, :lieu_naissance, :date_deces, :annee_deces, :identite_decret)",
              {
                  'nom': nom.get(),
                  'post_nom': post_nom.get(),
                  'prenom': prenom.get(),
                  'cause_deces': cause_deces.get(),
                  'date_naissance': date_naissance.get(),
                  'lieu_naissance': lieu_naissance.get(),
                  'date_deces': date_deces.get(),
                  'annee_deces': annee_deces.get(),
                  'identite_decret': identite_decret.get()
              })
    conn.commit()
    conn.close()
    messagebox.showinfo("Enregistré", "L'acte de décès a été enregistré avec succès")

# Création des champs du formulaire
nom = tk.Entry(fenetre, width=30)
nom.grid(row=0, column=1, padx=20, pady=(10, 0))
post_nom = tk.Entry(fenetre, width=30)
post_nom.grid(row=1, column=1)
prenom = tk.Entry(fenetre, width=30)
prenom.grid(row=2, column=1)
cause_deces = tk.Entry(fenetre, width=30)
cause_deces.grid(row=3, column=1)
date_naissance = tk.Entry(fenetre, width=30)
date_naissance.grid(row=4, column=1)
lieu_naissance = tk.Entry(fenetre, width=30)
lieu_naissance.grid(row=5, column=1)
date_deces = tk.Entry(fenetre, width=30)
date_deces.grid(row=6, column=1)
annee_deces = tk.Entry(fenetre, width=30)
annee_deces.grid(row=7, column=1)
identite_decret = tk.Entry(fenetre, width=30)
identite_decret.grid(row=8, column=1)

# Création des labels du formulaire
nom_label = tk.Label(fenetre, text="Nom")
nom_label.grid(row=0, column=0, pady=(10, 0))
post_nom_label = tk.Label(fenetre, text="Post-Nom")
post_nom_label.grid(row=1, column=0)
prenom_label = tk.Label(fenetre, text="Prénom")
prenom_label.grid(row=2, column=0)
cause_deces_label = tk.Label(fenetre, text="Cause du décès")
cause_deces_label.grid(row=3, column=0)
date_naissance_label = tk.Label(fenetre, text="Date de naissance")
date_naissance_label.grid(row=4, column=0)
lieu_naissance_label = tk.Label(fenetre, text="Lieu de naissance")
lieu_naissance_label.grid(row=5, column=0)
date_deces_label = tk.Label(fenetre, text="Date de décès")
date_deces_label.grid(row=6, column=0)
annee_deces_label = tk.Label(fenetre, text="Année de décès")
annee_deces_label.grid(row=7, column=0)
identite_decret_label = tk.Label(fenetre, text="Identité de décret")
identite_decret_label.grid(row=8, column=0)

# Création du bouton d'enregistrement
enregistrer_bouton = tk.Button(fenetre, text="Enregistrer", command=enregistrer)
enregistrer_bouton.grid(row=9, column=0, columnspan=2, pady=10, padx=10, ipadx=100)

fenetre.mainloop()

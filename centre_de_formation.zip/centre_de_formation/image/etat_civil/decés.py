from tkinter import*
from customtkinter import*
from PIL import Image,ImageTk










root=CTk()
"""haut = root.winfo_screenheight()
larg = root.winfo_screenwidth()
root.geometry("%dx%d+0+0" % (larg,haut))"""
root.geometry("1000x3000")
root.title("ATTESTATION DE MARIAGE")
root.config(bg="#91adad")

deces=CTkFrame(root,fg_color="white",width=800,height=1000)
deces.place(x=100,y=-500)

image2 = Image.open("rdc.png")
image2 = image2.resize((150,100))
image2 = ImageTk.PhotoImage(image2)
drapeau = Label(deces,image=image2,text=" ")
drapeau.place(x=600,y=30)




lbl=CTkLabel(deces,bg_color="white",text="REPUBLIQUE DEMOCRATIQUE DU CONGO",font=("Arial",17,"bold"))
lbl.place(x=5,y=5)

lbl=CTkLabel(deces,bg_color="white",text="Province de",font=("Arial",16,"bold"))
lbl.place(x=5,y=40)

province=CTkEntry(deces,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text=".......................................",width=200)
province.place(x=100,y=40)

lbl=CTkLabel(deces,bg_color="white",text="Ville de",font=("Arial",16,"bold"))
lbl.place(x=5,y=70)

ville=CTkEntry(deces,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text="..........................................",width=200)
ville.place(x=100,y=70)

lbl=CTkLabel(deces,bg_color="white",text="District de",font=("Arial",16,"bold"))
lbl.place(x=5,y=100)

district=CTkEntry(deces,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text="......................................",width=200)
district.place(x=100,y=100)

lbl=CTkLabel(deces,bg_color="white",text="Territoire/commune de",font=("Arial",16,"bold"))
lbl.place(x=5,y=130)

commune=CTkEntry(deces,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text=".......................................",width=200)
commune.place(x=180,y=130)

lbl=CTkLabel(deces,bg_color="white",text="Chefferie/Secteur de",font=("Arial",16,"bold"))
lbl.place(x=5,y=160)

secteur=CTkEntry(deces,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text="........................................",width=200)
secteur.place(x=180,y=160)

lbl=CTkLabel(deces,bg_color="white",text="Bureau principale de l'etat civil de",font=("Arial",16,"bold"))
lbl.place(x=5,y=190)

bureau=CTkEntry(deces,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text="........................................",width=200)
bureau.place(x=260,y=190)

lbl=CTkLabel(deces,bg_color="white",text="Bureau secondaire de l'etat civil de",font=("Arial",16,"bold"))
lbl.place(x=5,y=210)

bureau2=CTkEntry(deces,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text=".......................................",width=200)
bureau2.place(x=270,y=210)

lbl=CTkLabel(deces,bg_color="white",text="Acte n°",font=("Arial",16,"bold"))
lbl.place(x=5,y=240)

numacte=CTkEntry(deces,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text=".......................................",width=100)
numacte.place(x=60,y=240)
lbl=CTkLabel(deces,bg_color="white",text="Volume",font=("Arial",16,"bold"))
lbl.place(x=160,y=240)

volume=CTkEntry(deces,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text="........................................",width=100)
volume.place(x=230,y=240)

lbl=CTkLabel(deces,bg_color="white",text="ACTE DE DECES",font=("Arial",16,"bold"))
lbl.place(x=300,y=280)
acta=CTkFrame(deces,bg_color="black",fg_color="black",width=130,height=5)
acta.place(x=300,y=310)

lbl=CTkLabel(deces,bg_color="white",text="L'an deux mille",font=("Arial",16))
lbl.place(x=10,y=330)
année=CTkEntry(deces,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="................................",width=150)
année.place(x=140,y=330)

lbl=CTkLabel(deces,bg_color="white",text="Le",font=("Arial",16))
lbl.place(x=300,y=330)

le=CTkEntry(deces,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text=".....................................",width=150)
le.place(x=330,y=330)

lbl=CTkLabel(deces,bg_color="white",text="jour du mois de",font=("Arial",16))
lbl.place(x=470,y=330)

jour=CTkEntry(deces,bg_color="white",font=("Arial",15,"bold"),border_color="white",fg_color="white",placeholder_text=".............................",width=150)
jour.place(x=600,y=330)

lbl=CTkLabel(deces,bg_color="white",text="à",font=("Arial",16))
lbl.place(x=10,y=350)

lieu=CTkEntry(deces,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text=".......................................",width=150)
lieu.place(x=40,y=350)

lbl=CTkLabel(deces,bg_color="white",text="heures",font=("Arial",16))
lbl.place(x=180,y=350)

heure=CTkEntry(deces,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text=".......................................",width=150)
heure.place(x=250,y=350)

lbl=CTkLabel(deces,bg_color="white",text="minutes",font=("Arial",16))
lbl.place(x=420,y=350)

minute=CTkEntry(deces,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text=".....................................",width=250)
minute.place(x=500,y=350)


lbl=CTkLabel(deces,bg_color="white",text="Par devant nous",font=("Arial",16))
lbl.place(x=5,y=370)
nomoffice=CTkEntry(deces,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="...............................................................................................................................................",width=700)
nomoffice.place(x=140,y=370)
lbl=CTkLabel(deces,bg_color="white",text="Officier de l'etat civil de",font=("Arial",16))
lbl.place(x=10,y=390)
nomkincom=CTkEntry(deces,bg_color="white",font=("Arial",15),border_color="white",fg_color="white",placeholder_text="......................................................",width=500)
nomkincom.place(x=200,y=390)

lbl=CTkLabel(deces,bg_color="white",text="né(e) à",font=("Arial",16))
lbl.place(x=440,y=390)
lieunaiss=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text=".........................",width=500)
lieunaiss.place(x=500,y=390)

lbl=CTkLabel(deces,bg_color="white",text="le ",font=("Arial",16))
lbl.place(x=610,y=390)
datenaiss=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text=".............................",width=500)
datenaiss.place(x=625,y=390)

lbl=CTkLabel(deces,bg_color="white",text="profession ",font=("Arial",16))
lbl.place(x=10,y=410)
profession=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="....................................",width=500)
profession.place(x=90,y=410)

lbl=CTkLabel(deces,bg_color="white",text="résidant à ",font=("Arial",16))
lbl.place(x=250,y=410)
residecle=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="..........................................................................................................................",width=500)
residecle.place(x=320,y=410)

lbl=CTkLabel(deces,bg_color="white",text="lequel(laquelle)nous a déclaré ce qui suit: ",font=("Arial",16,"bold"))
lbl.place(x=150,y=440)

lbl=CTkLabel(deces,bg_color="white",text="le",font=("Arial",16))
lbl.place(x=10,y=470)
jourmort=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text=".....................................",width=500)
jourmort.place(x=30,y=470)

lbl=CTkLabel(deces,bg_color="white",text="jour du mois de ",font=("Arial",16))
lbl.place(x=200,y=470)
jourmois=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text=".....................................",width=500)
jourmois.place(x=312,y=470)

lbl=CTkLabel(deces,bg_color="white",text="l'an deux-mille ",font=("Arial",16))
lbl.place(x=480,y=470)
jourmois=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="......................................",width=500)
jourmois.place(x=585,y=470)

lbl=CTkLabel(deces,bg_color="white",text="heure ",font=("Arial",16))
lbl.place(x=10,y=490)
heuredcd=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="......................................",width=500)
heuredcd.place(x=50,y=490)

lbl=CTkLabel(deces,bg_color="white",text="minutes ",font=("Arial",16))
lbl.place(x=230,y=490)
minute=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="...........................",width=500)
minute.place(x=300,y=490)

lbl=CTkLabel(deces,bg_color="white",text="est décédé(e) à ",font=("Arial",16))
lbl.place(x=450,y=490)
lieudcd=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="............................",width=500)
lieudcd.place(x=560,y=490)

lbl=CTkLabel(deces,bg_color="white",text="le(la)nommé(e) ",font=("Arial",16))
lbl.place(x=10,y=510)
persdcd=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="....................................................",width=500)
persdcd.place(x=120,y=510)


lbl=CTkLabel(deces,bg_color="white",text="né(e) à",font=("Arial",16))
lbl.place(x=340,y=510)
lieunaiss=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text=".........................",width=500)
lieunaiss.place(x=380,y=510)

lbl=CTkLabel(deces,bg_color="white",text="le ",font=("Arial",16))
lbl.place(x=500,y=510)
datenaiss=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text=".......................................",width=500)
datenaiss.place(x=520,y=510)


lbl=CTkLabel(deces,bg_color="white",text="profession ",font=("Arial",16))
lbl.place(x=10,y=530)
profession=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="...........................................",width=500)
profession.place(x=90,y=530)

lbl=CTkLabel(deces,bg_color="white",text="résidant à ",font=("Arial",16))
lbl.place(x=290,y=530)

residence=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="..........................................................................................",width=400)
residence.place(x=380,y=530)

lbl=CTkLabel(deces,bg_color="white",text="fils(fille) de ",font=("Arial",16))
lbl.place(x=10,y=550)
resigemort=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="...................................................",width=500)
resigemort.place(x=90,y=550)

lbl=CTkLabel(deces,bg_color="white",text="né(e) à ",font=("Arial",16))
lbl.place(x=300,y=550)
lieunédef=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="...................................................",width=500)
lieunédef.place(x=350,y=550)

lbl=CTkLabel(deces,bg_color="white",text="Le ",font=("Arial",16))
lbl.place(x=570,y=550)
datenédef=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="...........................",width=500)
datenédef.place(x=600,y=550)

lbl=CTkLabel(deces,bg_color="white",text="Profession ",font=("Arial",16))
lbl.place(x=10,y=570)
profdef=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="...................................................",width=500)
profdef.place(x=100,y=570)

lbl=CTkLabel(deces,bg_color="white",text="Residant à ",font=("Arial",16))
lbl.place(x=300,y=570)
adressedef=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="..............................................................................................",width=500)
adressedef.place(x=380,y=570)

#---------------------------------------------------------------
lbl=CTkLabel(deces,bg_color="white",text="état civil: celibataire,marié(e) de,veuf(ve) de,divorce de",font=("Arial",16))
lbl.place(x=10,y=620)
étatcdef=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text=".........................................................................................",width=500)
étatcdef.place(x=400,y=620)

lbl=CTkLabel(deces,bg_color="white",text="né (e) à",font=("Arial",16))
lbl.place(x=10,y=640)
datefe=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="................................................................................................",width=500)
datefe.place(x=70,y=640)
lbl=CTkLabel(deces,bg_color="white",text="Le",font=("Arial",16))
lbl.place(x=470,y=640)
lieuf=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="..................................................................",width=500)
lieuf.place(x=490,y=640)

lbl=CTkLabel(deces,bg_color="white",text="profession",font=("Arial",16))
lbl.place(x=10,y=660)
proffe=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="................................................",width=500)
proffe.place(x=100,y=660)

lbl=CTkLabel(deces,bg_color="white",text="Residant à",font=("Arial",16))
lbl.place(x=300,y=660)
adressef=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="..............................................................................................",width=500)
adressef.place(x=380,y=660)

lbl=CTkLabel(deces,bg_color="white",text="Lecture de l'acte a été faite ou taduction da l'acte a été faite en ",font=("Arial",16))
lbl.place(x=10,y=680)
langue=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="..........................................................",width=500)
langue.place(x=465,y=680)
lbl=CTkLabel(deces,bg_color="white",text="langue que nous connaissons ou par",font=("Arial",16))
lbl.place(x=10,y=700)

parlelangue=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text="...................................................................",width=500)
parlelangue.place(x=280,y=700)
lbl=CTkLabel(deces,bg_color="white",text="l'interprete ayant preté serment",font=("Arial",16))
lbl.place(x=560,y=700)

lbl=CTkLabel(deces,bg_color="white",text="En foi de quoi nous avons dressé le present acte",font=("Arial",16))
lbl.place(x=10,y=750)
lbl=CTkLabel(deces,bg_color="white",text="Le(la) declarant(te)",font=("Arial",16))
lbl.place(x=10,y=770)

parlelangue=CTkEntry(deces,bg_color="white",font=("Arial",15), border_color="white",fg_color="white",placeholder_text=".................................................",width=500)
parlelangue.place(x=170,y=770)

lbl=CTkLabel(deces,bg_color="white",text="L'officier de l'état civil",font=("Arial",16))
lbl.place(x=500,y=770)



root.mainloop()

<?php
include_once("connexion.php");
try{
    $nom=$_POST['nom'];
    $postnom=$_POST['mail'];
    $sujet=$_POST['sujet'];
    $message=$_POST['message'];
    
    if(isset($_POST['submit'])){
        if(isset($_POST['nom'],$_POST['mail'],$_POST['sujet'],$_POST['message'])){
            $req=$conn->prepare("insert into nous_ecrire(nom,mail,sujet,message) values(:nom,:postnom, :sujet,:message)");
            $req->bindParam(':nom',$nom);
            $req->bindParam(':postnom',$postnom);
            $req->bindParam(':sujet',$sujet);
            $req->bindParam(':message',$message);
            $req->execute();
            header('location:conctact.html');
        }
    }
}

catch(PDOException $e)
{
    print"Erreur :".$e->getMessage();
}
?>
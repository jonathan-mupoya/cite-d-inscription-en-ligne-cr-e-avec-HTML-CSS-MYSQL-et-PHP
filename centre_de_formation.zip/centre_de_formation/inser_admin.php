<?php
include_once('connexion.php');

$nom=$_POST['nom'];
$prenom=$_POST['prenom'];
$photo=$_FILES['photo']['tmp_name'];
$photo=file_get_contents($photo);
$motpass=$_POST['motpass'];


$req=$conn->prepare("insert into administrateur (nom,mot_de_passe,prenom,photo) values(?,?,?,?) ");

$req->bindParam(1,$nom);
$req->bindParam(2,$motpass);
$req->bindParam(3,$prenom);
$req->bindParam(4,$photo, PDO::PARAM_LOB);

$req->execute();





?>